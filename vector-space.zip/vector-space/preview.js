/* A deliberately bounded, dependency-free Wolfram Language numeric preview.
 * Full Wolfram Language evaluation belongs to the included real-kernel bridge.
 * This interpreter never uses eval() or Function().
 */
(function (root) {
  'use strict';
  const own = (o, k) => Object.prototype.hasOwnProperty.call(o, k);
  const help = ' Switch to Wolfram Engine mode for the full Wolfram Language.';
  const fail = (message, at) => { throw new Error('Preview: ' + message + (at === undefined ? '' : ' (position ' + (at + 1) + ')') + '.' + help); };
  const constants = Object.freeze({Pi: Math.PI, E: Math.E, True: true, False: false, Infinity: Infinity, Indeterminate: NaN, Degree: Math.PI / 180});
  const aliases = { '\\[Pi]': 'Pi', '\\[ExponentialE]': 'E', '\\[Infinity]': 'Infinity' };

  function lex(source) {
    if (typeof source !== 'string') fail('Expected text');
    if (source.length > 100000) fail('The expression is too long for browser preview');
    const out = [];
    let p = 0;
    while (p < source.length) {
      if (/\s/.test(source[p])) { p++; continue; }
      if (source.slice(p, p + 2) === '(*') {
        const start = p;
        p += 2; let depth = 1;
        while (p < source.length && depth) {
          if (source.slice(p, p + 2) === '(*') { depth++; p += 2; }
          else if (source.slice(p, p + 2) === '*)') { depth--; p += 2; }
          else p++;
        }
        if (depth) fail('Unclosed Wolfram comment', start);
        continue;
      }
      if (source[p] === '\\') {
        const alias = Object.keys(aliases).find(key => source.startsWith(key, p));
        if (!alias) fail('This escaped symbol is not available in preview', p);
        out.push({kind:'id', value:aliases[alias], at:p}); p += alias.length; continue;
      }
      const number = source.slice(p).match(/^(?:\d+(?:\.\d*)?|\.\d+)(?:\*\^[+-]?\d+)?/);
      if (number) {
        out.push({kind:'num', value:Number(number[0].replace('*^','e')), at:p});
        p += number[0].length; continue;
      }
      const name = source.slice(p).match(/^[\p{L}$][\p{L}\p{N}$]*/u);
      if (name) { out.push({kind:'id', value:name[0], at:p}); p += name[0].length; continue; }
      const pair = source.slice(p,p+2);
      if (['++','--'].includes(pair)) fail('Increment and Decrement are unavailable in browser preview', p);
      if ([':=','==','!=','<=','>=','&&','||'].includes(pair)) {
        out.push({kind:pair,value:pair,at:p}); p += 2; continue;
      }
      const c = source[p];
      if ('+-*/^<>!=;,()[]{}_?'.includes(c)) {
        out.push({kind:c,value:c,at:p}); p++; continue;
      }
      fail('Unsupported character ' + JSON.stringify(c), p);
    }
    out.push({kind:'eof',value:'',at:p});
    return out;
  }

  class Parser {
    constructor(source) { this.tokens = lex(source); this.p = 0; this.depth = 0; }
    peek(kind) { return this.tokens[this.p].kind === kind; }
    next() { return this.tokens[this.p++]; }
    expect(kind) { if (!this.peek(kind)) fail('Expected ' + kind + ', found ' + (this.tokens[this.p].value || 'end of input'), this.tokens[this.p].at); return this.next(); }
    expr(min = 0) {
      if (++this.depth > 100) fail('Expression nesting is too deep');
      const token = this.next();
      let left;
      if (token.kind === 'num') left = {type:'value',value:token.value};
      else if (token.kind === 'id') {
        if (this.peek('[')) {
          this.next(); const args = [];
          if (!this.peek(']')) { do { args.push(this.expr()); if (!this.peek(',')) break; this.next(); } while (true); }
          this.expect(']'); left = {type:'call',name:token.value,args};
        } else left = {type:'symbol',name:token.value};
      } else if (token.kind === '(') { left = this.expr(); this.expect(')'); }
      else if (token.kind === '{') {
        const values = [];
        if (!this.peek('}')) { do { values.push(this.expr()); if (!this.peek(',')) break; this.next(); } while (true); }
        this.expect('}'); left = {type:'list',values};
      } else if (['+','-','!'].includes(token.kind)) left = {type:'unary',op:token.kind,arg:this.expr(token.kind==='!'?25:60)};
      else fail('Expected an expression, found ' + (token.value || 'end of input'), token.at);
      while (true) {
        const next = this.tokens[this.p];
        const implicit = ['num','id','(','{'].includes(next.kind);
        const op = implicit ? '*' : next.kind;
        const precedence = {'||':10,'&&':20,'==':30,'!=':30,'<':30,'>':30,'<=':30,'>=':30,'+':40,'-':40,'*':50,'/':50,'^':70}[op];
        if (precedence === undefined || precedence < min) break;
        if (!implicit) this.next();
        const right = this.expr(op === '^' ? precedence : precedence + 1);
        if (precedence === 30) {
          if (left.type === 'compare') { left.ops.push(op); left.values.push(right); }
          else left = {type:'compare',ops:[op],values:[left,right]};
        } else left = {type:'binary',op,left,right};
      }
      this.depth--;
      return left;
    }
    expression() {
      const ast = this.expr();
      if (!this.peek('eof')) fail('Unexpected ' + this.tokens[this.p].value, this.tokens[this.p].at);
      return ast;
    }
    definitions() {
      const statements = [];
      while (!this.peek('eof')) {
        if (this.peek(';')) { this.next(); continue; }
        const name = this.expect('id').value;
        if (own(constants,name) || own(functions,name) || ['If','Piecewise','And','Or','Not'].includes(name)) fail('Cannot redefine built-in ' + name + ' in preview');
        let params = null;
        if (this.peek('[')) {
          this.next(); params = [];
          if (!this.peek(']')) {
            do {
              const param = this.expect('id').value;
              this.expect('_');
              if (this.peek('?')) { this.next(); if (this.expect('id').value !== 'NumericQ') fail('Only ?NumericQ pattern tests are available in preview'); }
              if (params.includes(param)) fail('Repeated parameter ' + param);
              params.push(param);
              if (!this.peek(',')) break;
              this.next();
            } while (true);
          }
          this.expect(']');
        }
        const assignment = this.next();
        if (!['=',':='].includes(assignment.kind)) fail('Definitions must use = or :=', assignment.at);
        const ast = this.expr();
        statements.push({name,params,delayed:assignment.kind === ':=',ast});
        if (this.peek(';')) this.next();
        else if (!this.peek('eof')) fail('Separate definitions with a semicolon', this.tokens[this.p].at);
      }
      return statements;
    }
  }

  const numeric = n => typeof n === 'number';
  const real = n => numeric(n) && Number.isFinite(n);
  const power = (a,b) => a === 0 && b === 0 ? NaN : Math.pow(a,b);
  const roundWL = x => { const lower=Math.floor(x),fraction=x-lower;return fraction===0.5?(lower%2===0?lower:lower+1):Math.round(x); };
  const factorial = n => { if (!Number.isInteger(n) || n < 0) fail('Factorial preview requires a nonnegative integer'); let r=1; for (let k=2;k<=n;k++) r*=k; return r; };
  const functions = {
    Sin:[1,Math.sin], Cos:[1,Math.cos], Tan:[1,Math.tan], Cot:[1,x=>1/Math.tan(x)], Sec:[1,x=>1/Math.cos(x)], Csc:[1,x=>1/Math.sin(x)],
    ArcSin:[1,Math.asin], ArcCos:[1,Math.acos], ArcTan:[[1,2],(x,y)=>y === undefined ? Math.atan(x) : x===0&&y===0?NaN:Math.atan2(y,x)],
    Sinh:[1,Math.sinh], Cosh:[1,Math.cosh], Tanh:[1,Math.tanh], ArcSinh:[1,Math.asinh], ArcCosh:[1,Math.acosh], ArcTanh:[1,Math.atanh],
    Exp:[1,Math.exp], Log:[[1,2],(b,x)=>x === undefined ? Math.log(b) : Math.log(x)/Math.log(b)], Log2:[1,Math.log2], Log10:[1,Math.log10],
    Sqrt:[1,Math.sqrt], Abs:[1,Math.abs], Sign:[1,Math.sign], Floor:[1,Math.floor], Ceiling:[1,Math.ceil], Round:[1,roundWL],
    Power:[2,power], Mod:[2,(a,b)=>a-b*Math.floor(a/b)], Quotient:[2,(a,b)=>Math.floor(a/b)],
    Min:['many',(...xs)=>Math.min(...xs.flat(Infinity))], Max:['many',(...xs)=>Math.max(...xs.flat(Infinity))],
    UnitStep:['many',(...xs)=>xs.some(x=>x<0)?0:1], Boole:[1,x=>{if(typeof x!=='boolean')fail('Boole requires a Boolean result');return x?1:0;}],
    NumericQ:[1,x=>numeric(x)], NumberQ:[1,x=>numeric(x)], Re:[1,x=>x], Im:[1,()=>0], Conjugate:[1,x=>x],
    FractionalPart:[1,x=>x-Math.trunc(x)], IntegerPart:[1,Math.trunc], Factorial:[1,factorial],
    Norm:[1,x=>{if(!Array.isArray(x))return Math.abs(x);return Math.hypot(...x);}],
    Total:[1,x=>{if(!Array.isArray(x))fail('Total expects a list');return x.reduce((a,b)=>a+b,0);}],
    Dot:[2,(a,b)=>{if(!Array.isArray(a)||!Array.isArray(b)||a.length!==b.length)fail('Dot expects equal-length vectors');return a.reduce((s,x,i)=>s+x*b[i],0);}],
    Clip:[[1,2],(x,b=[-1,1])=>{if(!Array.isArray(b)||b.length!==2)fail('Clip bounds must be a pair');return Math.max(b[0],Math.min(b[1],x));}],
    Surd:[2,(x,n)=>x<0&&Number.isInteger(n)&&n%2 ? -Math.pow(-x,1/n) : Math.pow(x,1/n)]
  };

  function compile(definitions, components) {
    if (!Array.isArray(components) || components.length !== 3) fail('Provide three component expressions');
    const statements = new Parser(definitions || '').definitions();
    const asts = components.map(source=>new Parser(source).expression());
    const symbols = new Map(), helpers = new Map();
    let steps = 0, depth = 0;
    const bool = value=>{if(typeof value!=='boolean')fail('A condition did not evaluate to True or False');return value;};
    const evaluate = (node, local = Object.create(null)) => {
      if (++steps > 20000) fail('Evaluation exceeded the browser preview operation limit');
      switch (node.type) {
        case 'value': return node.value;
        case 'symbol':
          if (own(local,node.name)) return local[node.name];
          if (own(constants,node.name)) return constants[node.name];
          if (symbols.has(node.name)) { const entry=symbols.get(node.name); if(entry.type==='value')return entry.value; if(++depth>64)fail('Recursive definitions exceeded the browser preview limit'); const result=evaluate(entry.ast,local);depth--;return result; }
          fail('Unknown symbol ' + node.name);
          break;
        case 'list': return node.values.map(item=>evaluate(item,local));
        case 'unary': {const a=evaluate(node.arg,local);if(node.op==='!')return !bool(a);if(!numeric(a))fail('Arithmetic expects numeric values');return node.op==='-'?-a:a;}
        case 'binary': {
          const a=evaluate(node.left,local);
          if(node.op==='&&')return bool(a)&&bool(evaluate(node.right,local));
          if(node.op==='||')return bool(a)||bool(evaluate(node.right,local));
          const b=evaluate(node.right,local);
          if(!numeric(a)||!numeric(b))fail('Arithmetic expects numeric values');
          switch(node.op){case '+':return a+b;case '-':return a-b;case '*':return a*b;case '/':return a/b;case '^':return power(a,b);}
          break;
        }
        case 'compare': {
          let a=evaluate(node.values[0],local);
          for(let i=0;i<node.ops.length;i++){
            const b=evaluate(node.values[i+1],local),op=node.ops[i];
            const result=op==='=='?a===b:op==='!='?a!==b:op==='<'?a<b:op==='>'?a>b:op==='<='?a<=b:a>=b;
            if(!result)return false;a=b;
          }
          return true;
        }
        case 'call': {
          const args=node.args,name=node.name;
          if(name==='If') { if(args.length!==3)fail('If preview requires three arguments');return evaluate(bool(evaluate(args[0],local))?args[1]:args[2],local); }
          if(name==='Piecewise') {
            if(args.length<1||args.length>2||args[0].type!=='list')fail('Use Piecewise[{{value, condition}, ...}, default]');
            for(const pair of args[0].values){if(pair.type!=='list'||pair.values.length!==2)fail('Each Piecewise entry must be {value, condition}');if(bool(evaluate(pair.values[1],local)))return evaluate(pair.values[0],local);}
            return args.length===2?evaluate(args[1],local):0;
          }
          if(name==='And'||name==='Or') {for(const arg of args){const b=bool(evaluate(arg,local));if(name==='And'&&!b)return false;if(name==='Or'&&b)return true;}return name==='And';}
          if(name==='Not'){if(args.length!==1)fail('Not expects one argument');return !bool(evaluate(args[0],local));}
          if(helpers.has(name)) {
            const helper=helpers.get(name);
            if(helper.params.length!==args.length)fail(name+' expects '+helper.params.length+' arguments');
            const values=args.map(arg=>evaluate(arg,local));
            if(++depth>64)fail('Recursive definitions exceeded the browser preview limit');
            // Wolfram pattern variables are local to the rule, while x/y/z
            // remain dynamically bound to the numeric sample coordinates.
            const scope=Object.assign(Object.create(null),local);
            helper.params.forEach((param,i)=>{scope[param]=values[i];});
            const result=evaluate(helper.ast,scope);depth--;return result;
          }
          if(!own(functions,name))fail('Function '+name+' is unavailable in the browser preview');
          const [arity,fn]=functions[name];
          if(arity!=='many'&&(Array.isArray(arity)?!arity.includes(args.length):args.length!==arity))fail('Wrong number of arguments for '+name);
          const values=args.map(arg=>evaluate(arg,local));
          if(!['Boole','NumericQ','NumberQ','Norm','Total','Dot','Clip','Min','Max'].includes(name)&&values.some(x=>!numeric(x)))fail(name+' expects numeric arguments');
          return fn(...values);
        }
      }
      fail('Unsupported expression');
    };

    // Evaluate Set immediately, as Wolfram does; SetDelayed keeps the AST.
    // Immediate function definitions freeze existing scalar values, without
    // substituting symbols introduced as pattern parameters.
    const freeze = (node, params) => {
      if(node.type==='symbol'&&!params.includes(node.name)&&symbols.has(node.name)) {
        steps=0;depth=0;
        return {type:'value',value:evaluate(node)};
      }
      const copy={...node};
      for(const key of ['arg','left','right'])if(copy[key])copy[key]=freeze(copy[key],params);
      for(const key of ['args','values'])if(copy[key])copy[key]=copy[key].map(value=>freeze(value,params));
      return copy;
    };
    for(const statement of statements) {
      if(statement.params)helpers.set(statement.name,{params:statement.params,ast:statement.delayed?statement.ast:freeze(statement.ast,statement.params)});
      else {
        if(['x','y','z'].includes(statement.name))fail('Keep coordinate symbols x, y and z unassigned in definitions');
        steps=0;depth=0;
        symbols.set(statement.name,statement.delayed?{type:'delayed',ast:statement.ast}:{type:'value',value:evaluate(statement.ast)});
      }
    }
    // Check call names even in inactive branches. Unsupported language forms
    // must never silently look like they are supported by the preview.
    const validate = node=>{
      if(node.type==='call'&&!helpers.has(node.name)&&!own(functions,node.name)&&!['If','Piecewise','And','Or','Not'].includes(node.name))fail('Function '+node.name+' is unavailable in the browser preview');
      for(const key of ['arg','left','right'])if(node[key])validate(node[key]);
      for(const key of ['args','values'])if(node[key])node[key].forEach(validate);
    };
    asts.forEach(validate);for(const helper of helpers.values())validate(helper.ast);
    for(const value of symbols.values())if(value.ast)validate(value.ast);
    return function field(x,y,z) {
      if(![x,y,z].every(real))fail('Coordinates must be finite real numbers');
      steps=0;depth=0;
      const local=Object.assign(Object.create(null),{x,y,z});
      const values=asts.map(ast=>evaluate(ast,local));
      if(values.some(v=>typeof v!=='number'))fail('Each component must evaluate to a real scalar');
      return values;
    };
  }
  root.WLPreview = Object.freeze({compile,description:'Bounded numeric Wolfram Language preview; use a real kernel for full language support.'});
  if(typeof module!=='undefined'&&module.exports)module.exports=root.WLPreview;
})(typeof globalThis!=='undefined'?globalThis:window);
