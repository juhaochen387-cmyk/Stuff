/* Numerical field tools. Rendering and root searches are finite-resolution approximations. */
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  if (root) root.FieldMath = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  const norm = v => Math.hypot(v[0], v[1], v[2]);
  const dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
  const cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
  const add = (a, b, s = 1) => [a[0] + s * b[0], a[1] + s * b[1], a[2] + s * b[2]];
  const valid = v => v != null && v.length === 3 && Array.from(v).every(n => typeof n === 'number' && Number.isFinite(n));
  const inside = (p, bounds) => p.every((v, i) => v >= bounds[i][0] && v <= bounds[i][1]);
  function sample(field, p) {
    try {
      const value = field(p[0], p[1], p[2]);
      return valid(value) ? Array.from(value) : null;
    } catch (_) { return null; }
  }
  function validateBounds(bounds) {
    if (!Array.isArray(bounds) || bounds.length !== 3 || !bounds.every(b => Array.isArray(b) && b.length === 2 && b.every(Number.isFinite) && b[1] > b[0])) {
      throw new Error('Bounds must contain three finite increasing [minimum, maximum] pairs.');
    }
  }
  function interpolateGrid(vectors, n, bounds) {
    validateBounds(bounds);
    if (!Number.isInteger(n) || n < 2 || !vectors || vectors.length !== n * n * n) throw new Error('Sample grid size does not match its resolution.');
    const scales = bounds.map(b => (n - 1) / (b[1] - b[0]));
    return function (x, y, z) {
      const p = [x, y, z];
      if (!p.every(Number.isFinite) || !inside(p, bounds)) return null;
      const coords = p.map((v, i) => (v - bounds[i][0]) * scales[i]);
      const base = coords.map(c => Math.min(n - 2, Math.max(0, Math.floor(c))));
      const t = coords.map((c, i) => c - base[i]);
      const value = [0, 0, 0];
      for (let ix = 0; ix < 2; ix++) for (let iy = 0; iy < 2; iy++) for (let iz = 0; iz < 2; iz++) {
        const w = (ix ? t[0] : 1 - t[0]) * (iy ? t[1] : 1 - t[1]) * (iz ? t[2] : 1 - t[2]);
        // Exact grid nodes remain usable even if zero-weight neighboring cells are invalid.
        if (w === 0) continue;
        const v = vectors[((base[0] + ix) * n + base[1] + iy) * n + base[2] + iz];
        if (!valid(v)) return null;
        for (let j = 0; j < 3; j++) value[j] += w * v[j];
      }
      return valid(value) ? value : null;
    };
  }
  function jacobian(field, p, bounds, center) {
    const cols = [];
    for (let axis = 0; axis < 3; axis++) {
      const h = Math.max((bounds[axis][1] - bounds[axis][0]) * 1e-4, Math.abs(p[axis]) * 1e-7, 1e-8);
      const low = p.slice(), high = p.slice();
      low[axis] = Math.max(bounds[axis][0], p[axis] - h);
      high[axis] = Math.min(bounds[axis][1], p[axis] + h);
      let a = low[axis] === p[axis] ? center : sample(field, low);
      let b = high[axis] === p[axis] ? center : sample(field, high);
      let distance = high[axis] - low[axis];
      // A valid one-sided derivative is useful at a singularity next to a valid point.
      if (!a && b && high[axis] !== p[axis]) { a = center; distance = high[axis] - p[axis]; }
      if (!b && a && low[axis] !== p[axis]) { b = center; distance = p[axis] - low[axis]; }
      if (!a || !b || distance <= 0) return null;
      cols.push(b.map((v, j) => (v - a[j]) / distance));
    }
    return cols.every(valid) ? cols : null;
  }
  function diagnostics(field, p, bounds) {
    validateBounds(bounds);
    const v = inside(p, bounds) ? sample(field, p) : null;
    if (!v) return { v: null, speed: null, kappa: null, divergence: null, curl: null };
    const speed = norm(v), j = jacobian(field, p, bounds, v);
    if (!j) return { v, speed, kappa: null, divergence: null, curl: null };
    const acc = [0, 1, 2].map(k => j[0][k] * v[0] + j[1][k] * v[1] + j[2][k] * v[2]);
    const kappa = speed > 1e-12 ? norm(cross(v, acc)) / (speed * speed * speed) : null;
    return {
      v, speed, kappa: Number.isFinite(kappa) ? kappa : null,
      divergence: j[0][0] + j[1][1] + j[2][2],
      curl: [j[1][2] - j[2][1], j[2][0] - j[0][2], j[0][1] - j[1][0]]
    };
  }
  function unit(field, p, bounds, epsilon) {
    if (!inside(p, bounds)) return null;
    const v = sample(field, p);
    if (!v) return null;
    const length = norm(v);
    return length > epsilon ? v.map(x => x / length) : null;
  }
  function rk4(field, p, h, bounds, epsilon) {
    const k1 = unit(field, p, bounds, epsilon);
    if (!k1) return null;
    const k2 = unit(field, add(p, k1, h / 2), bounds, epsilon);
    if (!k2) return null;
    const k3 = unit(field, add(p, k2, h / 2), bounds, epsilon);
    if (!k3) return null;
    const k4 = unit(field, add(p, k3, h), bounds, epsilon);
    if (!k4) return null;
    const next = p.map((x, i) => x + h * (k1[i] + 2 * k2[i] + 2 * k3[i] + k4[i]) / 6);
    return inside(next, bounds) ? next : null;
  }
  function trace(field, seed, h, count, bounds, epsilon) {
    const points = [];
    let p = seed;
    for (let i = 0; i < count; i++) {
      const next = rk4(field, p, h, bounds, epsilon);
      if (!next || norm(add(next, p, -1)) < Math.abs(h) * 1e-5) break;
      points.push(next);
      p = next;
      // Stop after one approximate revolution instead of repeatedly tracing a closed orbit.
      if (i > 16 && norm(add(next, seed, -1)) < Math.abs(h) * 0.8) break;
    }
    return points;
  }
  function halton(index, base) {
    let f = 1, r = 0;
    while (index > 0) { f /= base; r += f * (index % base); index = Math.floor(index / base); }
    return r;
  }
  function solve3(cols, b) {
    const a = [0, 1, 2].map(row => [cols[0][row], cols[1][row], cols[2][row], b[row]]);
    const max = Math.max(...a.flatMap(row => row.slice(0, 3).map(Math.abs)));
    if (!max) return null;
    for (let i = 0; i < 3; i++) {
      let pivot = i;
      for (let k = i + 1; k < 3; k++) if (Math.abs(a[k][i]) > Math.abs(a[pivot][i])) pivot = k;
      if (Math.abs(a[pivot][i]) < max * 1e-12) return null;
      [a[i], a[pivot]] = [a[pivot], a[i]];
      const d = a[i][i];
      for (let k = i; k < 4; k++) a[i][k] /= d;
      for (let row = 0; row < 3; row++) if (row !== i) {
        const f = a[row][i];
        for (let k = i; k < 4; k++) a[row][k] -= f * a[i][k];
      }
    }
    const answer = a.map(row => row[3]);
    return valid(answer) ? answer : null;
  }
  function refineNull(field, seed, bounds, tolerance) {
    let p = seed.slice();
    for (let iteration = 0; iteration < 15; iteration++) {
      const v = sample(field, p);
      if (!v) return null;
      const residual = norm(v);
      if (residual <= tolerance) return { p, residual };
      const j = jacobian(field, p, bounds, v);
      if (!j) return null;
      const delta = solve3(j, v);
      if (!delta) return null;
      let accepted = false;
      for (let step = 1; step >= 1 / 64; step /= 2) {
        const candidate = add(p, delta, -step);
        if (!inside(candidate, bounds)) continue;
        const value = sample(field, candidate);
        if (value && norm(value) < residual) { p = candidate; accepted = true; break; }
      }
      if (!accepted) return null;
    }
    const v = sample(field, p);
    return v && norm(v) <= tolerance ? { p, residual: norm(v) } : null;
  }
  function build(field, bounds, options) {
    validateBounds(bounds);
    const opts = options || {};
    const density = Math.max(2, Math.min(21, Math.round(opts.density || 7)));
    const seedCount = Math.max(0, Math.min(400, Math.round(opts.seedCount === undefined ? 100 : opts.seedCount)));
    const steps = Math.max(8, Math.min(800, Math.round(opts.steps || 220)));
    const spans = bounds.map(b => b[1] - b[0]), minSpan = Math.min(...spans);
    const step = minSpan / 70, tolerance = 1e-7;
    const result = { arrows: [], lines: [], nulls: [], invalid: 0, maxSpeed: 0, maxKappa: 0, nullEverywhere: false, rootSearchIsApproximate: true };
    const candidates = [];
    let allZero = true;
    for (let ix = 0; ix < density; ix++) for (let iy = 0; iy < density; iy++) for (let iz = 0; iz < density; iz++) {
      const p = [ix, iy, iz].map((v, i) => bounds[i][0] + spans[i] * v / (density - 1));
      const d = diagnostics(field, p, bounds);
      if (!d.v) { result.invalid++; allZero = false; continue; }
      result.arrows.push({ p, v: d.v, speed: d.speed, kappa: d.kappa });
      result.maxSpeed = Math.max(result.maxSpeed, d.speed);
      if (d.kappa !== null) result.maxKappa = Math.max(result.maxKappa, d.kappa);
      if (d.speed > tolerance) allZero = false;
      candidates.push({ p, speed: d.speed });
    }
    result.nullEverywhere = allZero && result.arrows.length === density ** 3;
    if (result.nullEverywhere) return result;
    candidates.sort((a, b) => a.speed - b.speed);
    const rootSeeds = candidates.slice(0, 64).map(c => c.p);
    const epsilon = 1e-10;
    for (let i = 0; i < seedCount; i++) {
      const p = [2, 3, 5].map((base, j) => bounds[j][0] + spans[j] * (0.03 + 0.94 * halton(i + 1, base)));
      if (i < 36) rootSeeds.push(p);
      const d = diagnostics(field, p, bounds);
      if (!d.v || d.speed <= epsilon) continue;
      const before = trace(field, p, -step, Math.floor(steps / 2), bounds, epsilon);
      const after = trace(field, p, step, Math.ceil(steps / 2), bounds, epsilon);
      const points = before.reverse().concat([p], after);
      if (points.length > 2) result.lines.push({ points, speed: d.speed, kappa: d.kappa });
    }
    for (const seed of rootSeeds) {
      const root = refineNull(field, seed, bounds, tolerance);
      if (root && !result.nulls.some(other => norm(add(other.p, root.p, -1)) < minSpan * 1e-3)) result.nulls.push(root);
      if (result.nulls.length >= 48) break;
    }
    return result;
  }
  return { interpolateGrid, diagnostics, build };
});
