"""Assemble the dependency-free, double-clickable HTML. Python stdlib only."""
from pathlib import Path

ROOT = Path(__file__).resolve().parent
html = (ROOT / 'shell.html').read_text()
for marker, name in [('STYLE', 'style.css'), ('PREVIEW', 'preview.js'), ('FIELD', 'field.js'), ('RAYS', 'rays.js'), ('APP', 'app.js')]:
    text = (ROOT / name).read_text()
    if marker != 'STYLE':
        text = text.replace('</script', '<\\/script')
    if marker in ('FIELD', 'RAYS'):
        module_id = 'fieldModule' if marker == 'FIELD' else 'rayModule'
        html = html.replace('<script>/*__' + marker + '__*/</script>', '<script id="' + module_id + '">/*__' + marker + '__*/</script>')
    html = html.replace('/*__' + marker + '__*/', text)
if 'id="fieldModule"' not in html or 'id="rayModule"' not in html:
    raise SystemExit('Worker module IDs could not be set')
(ROOT / 'index.html').write_text(html)
print('Built index.html:', len(html.encode()), 'bytes')
