/* Vector Space — offline application controller and Canvas scene. */
(() => {
 'use strict';
 const $ = id => document.getElementById(id);
 const presets = {
  helix:{name:'Helical flow',definitions:'a = 0.35;',components:['-y','x','a']},
  vortex:{name:'Oscillating vortex',definitions:'a = 0.6;\nf[r_] := Sin[r];',components:['-y','x','a f[Sqrt[x^2 + y^2]]']},
  saddle:{name:'Saddle field',definitions:'a = 0.5;',components:['x','-y','-a z']},
  lens:{name:'Radial lens',definitions:'a = 0.7;\nf[r_] := a/(1 + r^2);',components:['-x f[Sqrt[x^2+y^2+z^2]]','-y f[Sqrt[x^2+y^2+z^2]]','-z f[Sqrt[x^2+y^2+z^2]]']},
  uniform:{name:'Uniform flow',definitions:'',components:['1','0','0']},
  null:{name:'Null field',definitions:'(* The flat reference: rays are straight. *)',components:['0','0','0']}
 };
 let state={field:null,data:null,bounds:[[-3,3],[-3,3],[-3,3]],title:'Helical flow',view:'field',paused:false,yaw:.65,pitch:.4,zoom:.78,dirty:true,ray:null,rayDirty:true,worker:null,renderId:0,appliedEngine:'preview'};
 const canvas=$('canvas'),ctx=canvas.getContext('2d'),cache=document.createElement('canvas'),cctx=cache.getContext('2d');
 let width=800,height=500,dpr=1,lastFrame=0,phase=0,drag=null,rayTimer;
 const valid=v=>Array.isArray(v)&&v.length===3&&v.every(x=>typeof x==='number'&&Number.isFinite(x));
 const fmt=v=>v===null||v===undefined||!Number.isFinite(v)?'—':Math.abs(v)<1e-9?'0':Math.abs(v)>1e5||Math.abs(v)<.0001?v.toExponential(2):Number(v.toPrecision(4)).toString();
 function message(text,type=''){ $('message').textContent=text;$('message').className='message '+type; }
 function boundsFromInputs(){const b=['x','y','z'].map(a=>[$(a+'min').valueAsNumber,$(a+'max').valueAsNumber]);if(!b.every(p=>p.every(Number.isFinite)&&p[0]<p[1]&&Number.isFinite(p[1]-p[0])))throw Error('Each domain minimum must be less than its maximum; use finite numbers.');return b;}
 function source(){return {definitions:$('definitions').value,components:['X','Y','Z'].map(a=>$('comp'+a).value),bounds:boundsFromInputs(),density:+$('density').value,resolution:+$('resolution').value};}
 function safe(field){return (x,y,z)=>{try{const v=field(x,y,z);return valid(v)?v:null;}catch(_){return null;}};}
 function markEdited(){ $('apply').firstElementChild.textContent='Apply field';message('Changes ready. Apply field to update the scene.'); }
 function bridgeURL(){const u=new URL($('endpoint').value);if(!['127.0.0.1','localhost'].includes(u.hostname)||u.protocol!=='http:')throw Error('Use the local HTTP bridge at 127.0.0.1 or localhost.');return u.origin;}
 async function checkBridge(){try{const r=await fetch(bridgeURL()+'/health',{signal:AbortSignal.timeout(5000)});const j=await r.json();if(!r.ok)throw Error(j.error||'Bridge request failed.');$('bridgeState').textContent=j.kernelAvailable?'Bridge connected. WolframScript detected; activation is checked during evaluation.':'Bridge connected. Install and activate WolframScript, then restart the bridge.';message(j.kernelAvailable?'Local bridge is ready.':'Bridge reachable; WolframScript is missing.',j.kernelAvailable?'success':'error');}catch(e){$('bridgeState').textContent='Start bridge.py, then use its local URL or session token.';message('Connection failed: '+e.message,'error');}}
 async function applyField(){
  $('apply').disabled=true;$('apply').firstElementChild.textContent='Evaluating…';message('Evaluating the field…');
  try{
   const s=source(),engine=$('engine').value;let field,invalid=0,grid=null;
   await new Promise(r=>setTimeout(r,20));
   if(engine==='wolfram'){
    if(!$('token').value.trim())throw Error('Start bridge.py and paste its session token, or open the local URL printed in its terminal.');
    const response=await fetch(bridgeURL()+'/sample',{method:'POST',headers:{'Content-Type':'application/json','X-Vector-Token':$('token').value.trim()},body:JSON.stringify(s),signal:AbortSignal.timeout(105000)});
    const j=await response.json();if(!response.ok)throw Error(j.error||'Wolfram evaluation failed.');
    if(j.resolution!==s.resolution||!Array.isArray(j.vectors))throw Error('The bridge returned an incompatible sample grid.');
    field=FieldMath.interpolateGrid(j.vectors,j.resolution,s.bounds);invalid=j.invalid;grid={vectors:j.vectors,n:j.resolution};
   }else{
    const compiled=WLPreview.compile(s.definitions,s.components);
    // A semantic error at every sample is surfaced with the original parser message.
    let any=false,firstError;for(const p of [[.17,.31,.43],[0,0,0],[1,1,1]].map(p=>p.map((x,i)=>Math.max(s.bounds[i][0],Math.min(s.bounds[i][1],x))))){try{if(valid(compiled(...p)))any=true;}catch(e){firstError=e;}}
    field=safe(compiled);
    if(!any&&firstError)throw firstError;
   }
   const data=FieldMath.build(field,s.bounds,{density:s.density,seedCount:78,steps:220});
   if(!data.arrows.length)throw Error('No finite real vectors at the sampled points. Check expressions or switch to a Wolfram kernel.');
   cancelRay();Object.assign(state,{field,data,bounds:s.bounds,appliedEngine:engine,grid,ray:null,rayDirty:true,dirty:true});
   state.title=state.pendingTitle||'Custom field';state.pendingTitle=null;$('sceneTitle').textContent=state.title;
   $('sceneSubtitle').textContent='F = ('+s.components.map(x=>x.trim().replace(/\s+/g,' ')).join(', ')+')';
   $('engineBadge').innerHTML='<i></i> '+(engine==='wolfram'?'Wolfram kernel · sampled':'Browser preview');
   $('legendMax').textContent=fmt(data.maxSpeed);
   $('sampleStatus').textContent=data.arrows.length.toLocaleString()+' valid field samples'+(data.invalid?' · '+data.invalid+' skipped':'');
   $('nullStatus').textContent=data.nullEverywhere?'All sampled vectors are zero':data.nulls.length+' approximate null'+(data.nulls.length===1?'':'s')+' found';
   $('methodStatus').textContent=state.view==='rays'?'CURVED-RAY MARCHING':'NORMALIZED RK4';
   inspect();message((engine==='wolfram'?'Wolfram evaluation complete. ':'Offline preview updated. ')+(invalid?invalid+' kernel samples skipped. ':'')+(data.invalid?'Invalid samples leave gaps.':'Drag the scene to explore.'),'success');
   if(state.view==='rays')scheduleRays();
  }catch(e){message(e.message+(e.message.includes('fetch')?' Start bridge.py and open the local URL it prints.':''),'error');}
  finally{$('apply').disabled=false;$('apply').firstElementChild.textContent='Apply field';}
 }
 function inspect(){if(!state.field)return;const p=['px','py','pz'].map(id=>$(id).valueAsNumber),inside=p.every((x,i)=>Number.isFinite(x)&&x>=state.bounds[i][0]&&x<=state.bounds[i][1]);const d=inside?FieldMath.diagnostics(state.field,p,state.bounds):{};
  $('mVector').textContent=d.v?'('+d.v.map(fmt).join(', ')+')':'—';$('mSpeed').textContent=fmt(d.speed);$('mKappa').textContent=fmt(d.kappa);$('mDiv').textContent=fmt(d.divergence);
  $('probeNote').textContent=!inside?'Point is outside the applied sampling domain.':!d.v?'Field is undefined at this point.':d.speed<1e-10?'Null point: streamline curvature is undefined.':(state.appliedEngine==='wolfram'?'Trilinearly interpolated Wolfram grid. ':'Numerical derivatives in Euclidean coordinates. ')+'Curl = ('+(d.curl?d.curl.map(fmt).join(', '):'undefined')+').';state.dirty=true;
 }
 function loadPreset(key){const p=presets[key];$('definitions').value=p.definitions;['X','Y','Z'].forEach((a,i)=>$('comp'+a).value=p.components[i]);state.pendingTitle=p.name;markEdited();if($('engine').value==='preview')applyField();}
 function resize(){const r=canvas.getBoundingClientRect();width=r.width;height=r.height;dpr=Math.min(devicePixelRatio||1,2);canvas.width=cache.width=Math.round(width*dpr);canvas.height=cache.height=Math.round(height*dpr);state.dirty=true;if(state.view==='rays')scheduleRays();}
 function project(p){const center=state.bounds.map(b=>(b[0]+b[1])/2),span=Math.max(...state.bounds.map(b=>b[1]-b[0]));const [x,y,z]=p.map((x,i)=>(x-center[i])/span*6),cy=Math.cos(state.yaw),sy=Math.sin(state.yaw),cp=Math.cos(state.pitch),sp=Math.sin(state.pitch);const rx=x*cy+y*sy,ry=-x*sy*sp+y*cy*sp+z*cp,depth=x*sy*cp-y*cy*cp+z*sp;const scale=Math.min(width*.122,height*.155)*state.zoom/(1-depth/14);return [width*.51+rx*scale,height*.53-ry*scale,depth,scale];}
 function color(speed,alpha=1){const t=Math.max(0,Math.min(1,speed/(state.data?.maxSpeed||1)));let a,b,q;if(t<.5){a=[91,184,207];b=[129,206,183];q=t*2;}else{a=[129,206,183];b=[255,143,102];q=(t-.5)*2;}return 'rgba('+a.map((x,i)=>Math.round(x+(b[i]-x)*q)).join(',')+','+alpha+')';}
 function segment(c,a,b,stroke,lw=1){const p=project(a),q=project(b);c.beginPath();c.moveTo(p[0],p[1]);c.lineTo(q[0],q[1]);c.strokeStyle=stroke;c.lineWidth=lw;c.stroke();}
 function drawGrid(c){const b=state.bounds,min=b.map(x=>x[0]),max=b.map(x=>x[1]);c.lineWidth=1;
  for(let i=0;i<=10;i++){const x=b[0][0]+(b[0][1]-b[0][0])*i/10,y=b[1][0]+(b[1][1]-b[1][0])*i/10;segment(c,[x,min[1],min[2]],[x,max[1],min[2]],'#38505e55');segment(c,[min[0],y,min[2]],[max[0],y,min[2]],'#38505e55');}
  for(let axis=0;axis<3;axis++)for(let k=0;k<4;k++){const a=min.slice(),z=min.slice();let bit=0;for(let j=0;j<3;j++)if(j!==axis){a[j]=z[j]=((k>>bit++)&1)?max[j]:min[j];}z[axis]=max[axis];segment(c,a,z,'#5e7c8f35');}
  const origin=b.map(p=>Math.max(p[0],Math.min(p[1],0)));['#e69580','#83ba9e','#8ea5d9'].forEach((co,i)=>{const end=origin.slice();end[i]=max[i];segment(c,origin,end,co+'77');const p=project(end);c.fillStyle=co;c.font='11px Consolas,monospace';c.fillText(['x','y','z'][i],p[0]+8,p[1]+3);});
 }
 function drawStatic(){
  cctx.setTransform(dpr,0,0,dpr,0,0);cctx.clearRect(0,0,width,height);const bg=cctx.createRadialGradient(width*.5,height*.52,0,width*.5,height*.52,Math.max(width,height)*.65);bg.addColorStop(0,'#142735');bg.addColorStop(1,'#0b121c');cctx.fillStyle=bg;cctx.fillRect(0,0,width,height);
  if(state.view==='rays'){
   if(state.ray)cctx.drawImage(state.ray,0,0,width,height);
   else{cctx.fillStyle='#5c778b';cctx.font='12px system-ui';cctx.textAlign='center';cctx.fillText('A field bends the path of light.',width/2,height*.6);cctx.textAlign='left';}
   state.dirty=false;return;
  }
  if($('showGrid').checked)drawGrid(cctx);const data=state.data;if(!data){state.dirty=false;return;}
  if($('showLines').checked){const lines=data.lines.slice().sort((a,b)=>project(a.points[Math.floor(a.points.length/2)])[2]-project(b.points[Math.floor(b.points.length/2)])[2]);for(const l of lines){cctx.beginPath();for(let i=0;i<l.points.length;i+=2){const p=project(l.points[i]);if(i===0)cctx.moveTo(p[0],p[1]);else cctx.lineTo(p[0],p[1]);}cctx.strokeStyle=color(l.speed,.58);cctx.lineWidth=1.05;cctx.stroke();}}
  if($('showArrows').checked){const span=Math.min(...state.bounds.map(b=>b[1]-b[0])),len=span/(+$('density').value)*.43;for(const a of data.arrows){if(a.speed<1e-10)continue;const q=a.p.map((x,i)=>x+a.v[i]/a.speed*len),p=project(a.p),r=project(q),dx=r[0]-p[0],dy=r[1]-p[1],ang=Math.atan2(dy,dx);if(Math.hypot(dx,dy)<1)continue;cctx.strokeStyle=color(a.speed,.5);cctx.lineWidth=.8;cctx.beginPath();cctx.moveTo(p[0],p[1]);cctx.lineTo(r[0],r[1]);cctx.moveTo(r[0]-3.5*Math.cos(ang-.45),r[1]-3.5*Math.sin(ang-.45));cctx.lineTo(r[0],r[1]);cctx.lineTo(r[0]-3.5*Math.cos(ang+.45),r[1]-3.5*Math.sin(ang+.45));cctx.stroke();}}
  if($('showNulls').checked){for(const n of data.nulls){const p=project(n.p);cctx.beginPath();cctx.arc(p[0],p[1],4.5,0,Math.PI*2);cctx.fillStyle='#ffc296';cctx.fill();cctx.strokeStyle='#422c22';cctx.lineWidth=2;cctx.stroke();}}
  const point=['px','py','pz'].map(id=>$(id).valueAsNumber);if(point.every((x,i)=>Number.isFinite(x)&&x>=state.bounds[i][0]&&x<=state.bounds[i][1])){const p=project(point);cctx.strokeStyle='#e2edf5bb';cctx.lineWidth=1;cctx.beginPath();cctx.arc(p[0],p[1],6,0,Math.PI*2);cctx.moveTo(p[0]-10,p[1]);cctx.lineTo(p[0]+10,p[1]);cctx.moveTo(p[0],p[1]-10);cctx.lineTo(p[0],p[1]+10);cctx.stroke();}
  if(data.nullEverywhere){cctx.fillStyle='#b2c7d6';cctx.font='14px system-ui';cctx.textAlign='center';cctx.fillText('The field vanishes at every sampled point.',width*.5,height*.46);cctx.font='11px system-ui';cctx.fillStyle='#748c9e';cctx.fillText('Open Curved rays to see the flat reference.',width*.5,height*.46+24);cctx.textAlign='left';}
  state.dirty=false;
 }
 function animate(time){requestAnimationFrame(animate);if(time-lastFrame<32)return;const dt=Math.min((time-lastFrame)/1000,.1);lastFrame=time;if(state.paused&&!state.dirty)return;if(state.dirty)drawStatic();ctx.setTransform(1,0,0,1,0,0);ctx.clearRect(0,0,canvas.width,canvas.height);ctx.drawImage(cache,0,0);if(state.view!=='field'||!state.data||!$('showLines').checked)return;if(!state.paused)phase+=dt*.045;ctx.setTransform(dpr,0,0,dpr,0,0);for(let i=0;i<state.data.lines.length;i++){const l=state.data.lines[i],v=(phase+i*.6180339)%1,index=Math.floor(v*(l.points.length-1)),t=v*(l.points.length-1)-index,a=l.points[index],b=l.points[Math.min(index+1,l.points.length-1)],p=project(a.map((x,j)=>x+(b[j]-x)*t));ctx.fillStyle=color(l.speed,.95);ctx.beginPath();ctx.arc(p[0],p[1],1.6,0,Math.PI*2);ctx.fill();}}
 function cancelRay(){clearTimeout(rayTimer);state.renderId++;if(state.worker){state.worker.terminate();state.worker=null;}$('renderNotice').hidden=true;$('renderRays').disabled=false;}
 function rayGrid(){if(state.grid)return state.grid;const n=17,vectors=[];for(let i=0;i<n;i++)for(let j=0;j<n;j++)for(let k=0;k<n;k++){const p=[i,j,k].map((x,a)=>state.bounds[a][0]+(state.bounds[a][1]-state.bounds[a][0])*x/(n-1));vectors.push(state.field(...p));}return {vectors,n};}
 function scheduleRays(){if(state.view!=='rays'||!state.field)return;cancelRay();state.rayDirty=true;rayTimer=setTimeout(renderRays,180);}
 function renderRays(){
  if(!state.field)return;cancelRay();const id=state.renderId;const w=Math.min(440,Math.max(220,Math.round(width*.46))),h=Math.max(120,Math.round(w*height/width)),grid=rayGrid();const options={width:w,height:h,bounds:state.bounds,strength:+$('strength').value,yaw:state.yaw-.65,pitch:state.pitch-.4,cameraDistance:Math.sqrt(90)*.78/state.zoom};
  options.cameraDistance*=Math.min(...state.bounds.map(b=>b[1]-b[0]))/5;
  $('renderNotice').hidden=false;$('renderNotice').textContent='Tracing curved rays…';$('renderRays').disabled=true;
  const finish=pixels=>{if(id!==state.renderId)return;const off=document.createElement('canvas');off.width=w;off.height=h;off.getContext('2d').putImageData(new ImageData(new Uint8ClampedArray(pixels),w,h),0,0);state.ray=off;state.rayDirty=false;state.dirty=true;$('renderNotice').hidden=true;$('renderRays').disabled=false;if(state.worker){state.worker.terminate();state.worker=null;}};
  try{
   const script=$('fieldModule').textContent+'\n'+$('rayModule').textContent+'\nonmessage=e=>{try{const p=e.data;const field=FieldMath.interpolateGrid(p.vectors,p.n,p.options.bounds);const pixels=RayRenderer.render({...p.options,field});postMessage({pixels},[pixels.buffer]);}catch(e){postMessage({error:e.message});}};';
   const url=URL.createObjectURL(new Blob([script],{type:'text/javascript'}));const worker=new Worker(url);URL.revokeObjectURL(url);state.worker=worker;worker.onmessage=e=>{if(e.data.error){cancelRay();message('Ray render: '+e.data.error,'error');}else finish(e.data.pixels);};worker.onerror=()=>{cancelRay();message('Ray worker could not start in this browser. Open the local bridge URL to enable rendering.','error');};worker.postMessage({vectors:grid.vectors,n:grid.n,options});
  }catch(e){cancelRay();message('Ray rendering needs browser Web Worker support: '+e.message,'error');}
 }
 function switchView(view){state.view=view;$('fieldTab').classList.toggle('active',view==='field');$('rayTab').classList.toggle('active',view==='rays');$('fieldTab').setAttribute('aria-selected',view==='field');$('rayTab').setAttribute('aria-selected',view==='rays');$('fieldControls').hidden=view!=='field';$('rayControls').hidden=view!=='rays';$('legend').hidden=view!=='field';$('pause').hidden=view!=='field';$('viewEyebrow').textContent=view==='field'?'02 / EXPLORE THE FIELD':'02 / FOLLOW THE LIGHT';$('sceneHint').textContent=view==='field'?'Drag to orbit · Scroll to zoom':'Field-driven bending · Drag to orbit';$('methodStatus').textContent=view==='field'?'NORMALIZED RK4':'CURVED-RAY MARCHING';state.dirty=true;if(view==='rays'&&state.rayDirty)scheduleRays();else if(view==='field')cancelRay();}
 function updateEngine(){const full=$('engine').value==='wolfram';$('kernelSettings').hidden=!full;$('engineSummary').textContent=full?'WOLFRAM KERNEL':'BROWSER PREVIEW';$('engineHelp').textContent=full?'Source is evaluated unchanged by your local Wolfram kernel. Only trusted code should be run.':'Common numerical expressions and helper definitions work offline. Use a Wolfram kernel for the full language.';markEdited();}
 function download(blob,name){const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),2000);}
 $('apply').onclick=applyField;$('inspectBtn').onclick=inspect;$('preset').onchange=e=>loadPreset(e.target.value);
 $('engine').onchange=updateEngine;$('checkBridge').onclick=checkBridge;
 $('fieldTab').onclick=()=>switchView('field');$('rayTab').onclick=()=>switchView('rays');
 $('density').oninput=()=>{$('densityOut').textContent=Array(3).fill($('density').value).join(' × ');markEdited();};
 $('resolution').oninput=()=>{$('resolutionOut').textContent=$('resolution').value+'³';markEdited();};
 $('strength').oninput=()=>{$('strengthOut').textContent=(+$('strength').value).toFixed(2);scheduleRays();};$('renderRays').onclick=renderRays;
 ['showLines','showArrows','showGrid','showNulls'].forEach(id=>$(id).onchange=()=>state.dirty=true);
 ['compX','compY','compZ','definitions','xmin','xmax','ymin','ymax','zmin','zmax'].forEach(id=>$(id).addEventListener('input',()=>{state.pendingTitle='Custom field';markEdited();}));
 ['px','py','pz'].forEach(id=>$(id).addEventListener('keydown',e=>{if(e.key==='Enter')inspect();}));
 document.addEventListener('keydown',e=>{if((e.ctrlKey||e.metaKey)&&e.key==='Enter'){e.preventDefault();applyField();}});
 $('guideBtn').onclick=()=>$('guide').showModal();$('closeGuide').onclick=()=>$('guide').close();$('guide').onclick=e=>{if(e.target===$('guide')&&e.offsetX<0)$('guide').close();};
 $('pause').onclick=()=>{state.paused=!state.paused;$('pause').textContent=state.paused?'▶  Resume motion':'Ⅱ  Pause motion';state.dirty=true;};
 $('resetView').onclick=()=>{state.yaw=.65;state.pitch=.4;state.zoom=.78;state.dirty=true;if(state.view==='rays')scheduleRays();};
 $('snapshot').onclick=()=>canvas.toBlob(b=>{if(b)download(b,'vector-space.png');});
 $('fullScreen').onclick=async()=>{try{if(document.fullscreenElement)await document.exitFullscreen();else await $('viewport').requestFullscreen();}catch(e){message('Fullscreen is unavailable in this browser.','error');}};
 canvas.addEventListener('pointerdown',e=>{if(e.button!==0)return;drag=[e.clientX,e.clientY,state.yaw,state.pitch];canvas.setPointerCapture(e.pointerId);});
 canvas.addEventListener('pointermove',e=>{if(!drag)return;state.yaw=drag[2]+(e.clientX-drag[0])*.008;state.pitch=Math.max(-1.15,Math.min(1.15,drag[3]+(e.clientY-drag[1])*.006));state.dirty=true;if(state.view==='rays'){state.rayDirty=true;cancelRay();}});
 const endDrag=()=>{if(drag&&state.view==='rays')scheduleRays();drag=null;};canvas.addEventListener('pointerup',endDrag);canvas.addEventListener('pointercancel',endDrag);
 canvas.addEventListener('wheel',e=>{e.preventDefault();state.zoom=Math.max(.45,Math.min(2.2,state.zoom*Math.exp(-e.deltaY*.001)));state.dirty=true;if(state.view==='rays')scheduleRays();},{passive:false});
 canvas.addEventListener('keydown',e=>{if(!['ArrowLeft','ArrowRight','ArrowUp','ArrowDown','+','=','-'].includes(e.key))return;e.preventDefault();if(e.key==='ArrowLeft')state.yaw-=.1;if(e.key==='ArrowRight')state.yaw+=.1;if(e.key==='ArrowUp')state.pitch=Math.min(1.15,state.pitch+.1);if(e.key==='ArrowDown')state.pitch=Math.max(-1.15,state.pitch-.1);if(e.key==='+'||e.key==='=')state.zoom=Math.min(2.2,state.zoom*1.1);if(e.key==='-')state.zoom=Math.max(.45,state.zoom/1.1);state.dirty=true;if(state.view==='rays')scheduleRays();});
 $('saveBtn').onclick=()=>{try{const s=source();download(new Blob([JSON.stringify({format:'vector-space',version:1,...s,title:state.pendingTitle||state.title},null,2)],{type:'application/json'}),'vector-space-project.json');message('Project saved. Session tokens are excluded.','success');}catch(e){message(e.message,'error');}};
 $('loadBtn').onclick=()=>$('loadFile').click();$('loadFile').onchange=async e=>{try{const file=e.target.files[0];if(!file)return;if(file.size>2*1024*1024)throw Error('Project is too large (maximum 2 MB).');const j=JSON.parse(await file.text());if(j.format!=='vector-space'||j.version!==1||typeof j.definitions!=='string'||!Array.isArray(j.components)||j.components.length!==3||!j.components.every(v=>typeof v==='string')||!Array.isArray(j.bounds)||j.bounds.length!==3||!j.bounds.every(b=>Array.isArray(b)&&b.length===2&&b.every(v=>typeof v==='number'&&Number.isFinite(v))&&b[0]<b[1]))throw Error('This is not a valid Vector Space project.');$('definitions').value=j.definitions;['X','Y','Z'].forEach((a,i)=>$('comp'+a).value=j.components[i]);['x','y','z'].forEach((a,i)=>{$(a+'min').value=j.bounds[i][0];$(a+'max').value=j.bounds[i][1];});$('density').value=[3,5,7,9,11].includes(j.density)?j.density:7;$('density').oninput();$('resolution').value=Number.isInteger(j.resolution)&&j.resolution>=7&&j.resolution<=31?j.resolution:17;$('resolution').oninput();state.pendingTitle=typeof j.title==='string'?j.title.slice(0,80):'Imported field';message('Project loaded. Apply field to evaluate it.','success');}catch(err){message(err.message,'error');}finally{e.target.value='';}};
 new ResizeObserver(resize).observe(canvas);
 const token=new URLSearchParams(location.hash.slice(1)).get('token');if(token){$('token').value=token;if(['localhost','127.0.0.1'].includes(location.hostname))$('endpoint').value=location.origin;$('engine').value='wolfram';$('engineSection').open=true;updateEngine();try{history.replaceState(null,'',location.pathname);}catch(_){}}
 state.pendingTitle='Helical flow';requestAnimationFrame(animate);resize();
 if(token){message('Local bridge token loaded. Apply field to run the Wolfram kernel.');/* Keep execution explicit in kernel mode. */}else applyField();
 window.VectorSpace={getState:()=>state,applyField,inspect,switchView};
})();
