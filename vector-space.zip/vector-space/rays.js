/* Vector field ray renderer. No libraries or network access required.
 * The field defines the steering connection p'=u,
 * u'=strength (F - (F.u)u). It does not change the Euclidean metric.
 */
(function (root) {
  'use strict';

  const EPS = 1e-10;
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
  const unit = (a) => {
    const m = Math.hypot(a[0], a[1], a[2]);
    return m > EPS ? [a[0] / m, a[1] / m, a[2] / m] : [0, 0, 0];
  };
  const cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];

  function checkedBounds(bounds) {
    const b = bounds || [[-3, 3], [-3, 3], [-3, 3]];
    if (b.length !== 3 || b.some(a => !Array.isArray(a) || a.length !== 2 || !Number.isFinite(a[0]) || !Number.isFinite(a[1]) || a[0] >= a[1])) {
      throw new RangeError('bounds must contain three finite [minimum, maximum] pairs.');
    }
    return b;
  }

  function inside(p, b, margin) {
    margin = margin || 0;
    return p[0] >= b[0][0] - margin && p[0] <= b[0][1] + margin &&
      p[1] >= b[1][0] - margin && p[1] <= b[1][1] + margin &&
      p[2] >= b[2][0] - margin && p[2] <= b[2][1] + margin;
  }

  function sample(field, p, bounds) {
    if (bounds && !inside(p, bounds)) return [0, 0, 0];
    const f = field(p[0], p[1], p[2]);
    if (!f || f.length !== 3 || !Number.isFinite(f[0]) || !Number.isFinite(f[1]) || !Number.isFinite(f[2])) {
      const e = new RangeError('Field is undefined or non-real at (' + p.map(v => Number(v.toPrecision(7))).join(', ') + '); every in-domain sample must be a finite real triple.');
      e.name = 'FieldSampleError';
      throw e;
    }
    return f;
  }

  function rk2(p, u, field, strength, h, bounds, initialField) {
    const f = initialField || sample(field, p, bounds);
    const d = dot(f, u);
    const m = [p[0] + h * 0.5 * u[0], p[1] + h * 0.5 * u[1], p[2] + h * 0.5 * u[2]];
    const v = unit([u[0] + h * 0.5 * strength * (f[0] - d * u[0]), u[1] + h * 0.5 * strength * (f[1] - d * u[1]), u[2] + h * 0.5 * strength * (f[2] - d * u[2])]);
    const fm = sample(field, m, bounds), dm = dot(fm, v);
    return {
      p: [p[0] + h * v[0], p[1] + h * v[1], p[2] + h * v[2]],
      u: unit([u[0] + h * strength * (fm[0] - dm * v[0]), u[1] + h * strength * (fm[1] - dm * v[1]), u[2] + h * strength * (fm[2] - dm * v[2])])
    };
  }

  /** A testable midpoint integrator. step is arc length; directions stay unit. */
  function traceRay(options) {
    const o = options || {};
    let p = (o.origin || [0, 0, 0]).slice();
    const initialDirection = o.direction || [1, 0, 0];
    if (p.length !== 3 || initialDirection.length !== 3 || !p.every(Number.isFinite) || !initialDirection.every(Number.isFinite)) throw new RangeError('Ray origin and direction must be finite triples.');
    let u = unit(initialDirection);
    const field = o.field || (() => [0, 0, 0]);
    const strength = o.strength === undefined ? 0.35 : Number(o.strength);
    const h = o.step === undefined ? 0.02 : Number(o.step);
    const steps = o.steps === undefined ? 100 : Number(o.steps);
    if (!Number.isFinite(strength) || !(h > 0) || !Number.isFinite(h) || !Number.isInteger(steps) || steps < 0 || steps > 100000) throw new RangeError('Invalid ray integration settings.');
    if (!p.every(Number.isFinite) || Math.hypot(...u) < EPS) throw new RangeError('Ray origin and direction must be finite; direction must be nonzero.');
    const b = o.bounds ? checkedBounds(o.bounds) : null;
    const path = [p.slice()];
    for (let i = 0; i < steps; i++) {
      if (o.signal && o.signal.aborted) throw abortError();
      const next = rk2(p, u, field, strength, h, b);
      p = next.p; u = next.u; path.push(p.slice());
    }
    return {position: p, direction: u, path};
  }

  function abortError() {
    const e = new Error('Rendering cancelled.'); e.name = 'AbortError'; return e;
  }

  function boxEntry(p, u, b) {
    let near = 0, far = Infinity;
    for (let a = 0; a < 3; a++) {
      if (Math.abs(u[a]) < EPS) {
        if (p[a] < b[a][0] || p[a] > b[a][1]) return null;
      } else {
        let t0 = (b[a][0] - p[a]) / u[a], t1 = (b[a][1] - p[a]) / u[a];
        if (t0 > t1) { const t = t0; t0 = t1; t1 = t; }
        near = Math.max(near, t0); far = Math.min(far, t1);
        if (near > far) return null;
      }
    }
    return far >= 0 ? [near, far] : null;
  }

  function sceneFor(bounds) {
    const s = Math.min(...bounds.map(b => b[1] - b[0])) / 5;
    const cx = (bounds[0][0] + bounds[0][1]) / 2, cy = (bounds[1][0] + bounds[1][1]) / 2;
    const floor = bounds[2][0];
    return {
      scale: s, floor, cx, cy,
      spheres: [
        {c: [cx + 0.15 * s, cy + 0.35 * s, floor + 1.0 * s], r: 1.0 * s, color: [0.16, 0.78, 0.74]},
        {c: [cx - 1.45 * s, cy - 0.5 * s, floor + 0.62 * s], r: 0.62 * s, color: [1.0, 0.45, 0.27]},
        {c: [cx + 1.5 * s, cy - 0.4 * s, floor + 0.52 * s], r: 0.52 * s, color: [0.6, 0.5, 0.95]},
        {c: [cx - 1.05 * s, cy + 1.65 * s, floor + 0.34 * s], r: 0.34 * s, color: [0.96, 0.77, 0.3]}
      ]
    };
  }

  // Analytic intersections are restricted to each short curved-path chord.
  function hitScene(p, u, limit, scene) {
    let closest = limit, result = null;
    for (let i = 0; i < scene.spheres.length; i++) {
      const sphere = scene.spheres[i], c = sphere.c;
      const ox = p[0] - c[0], oy = p[1] - c[1], oz = p[2] - c[2];
      const b = ox * u[0] + oy * u[1] + oz * u[2];
      const discriminant = b * b - (ox * ox + oy * oy + oz * oz - sphere.r * sphere.r);
      if (discriminant < 0) continue;
      const root = Math.sqrt(discriminant);
      let t = -b - root;
      if (t < 1e-6) t = -b + root;
      if (t > 1e-6 && t <= closest) {
        closest = t;
        const q = [p[0] + t * u[0], p[1] + t * u[1], p[2] + t * u[2]];
        result = {p: q, n: [(q[0] - c[0]) / sphere.r, (q[1] - c[1]) / sphere.r, (q[2] - c[2]) / sphere.r], sphere, index: i, t};
      }
    }
    if (u[2] < -EPS && p[2] > scene.floor) {
      const t = (scene.floor - p[2]) / u[2];
      if (t > 1e-6 && t <= closest) result = {p: [p[0] + t * u[0], p[1] + t * u[1], scene.floor], n: [0, 0, 1], sphere: null, index: -1, t};
    }
    return result;
  }

  const LIGHT = unit([-0.5, -0.65, 1]);
  function sky(u) {
    const t = clamp(0.5 + u[2] * 0.8, 0, 1);
    return [0.095 + 0.065 * (1 - t), 0.125 + 0.095 * (1 - t), 0.19 + 0.115 * (1 - t)];
  }

  function shade(hit, u, scene, distance) {
    const p = hit.p, n = hit.n;
    let color, roughness;
    if (hit.sphere) { color = hit.sphere.color; roughness = 0.32; }
    else {
      const x = (p[0] - scene.cx) / scene.scale, y = (p[1] - scene.cy) / scene.scale;
      const checker = ((Math.floor(x) + Math.floor(y)) % 2 + 2) % 2;
      color = checker ? [0.24, 0.3, 0.36] : [0.32, 0.39, 0.46];
      const edge = Math.min(x - Math.floor(x), Math.ceil(x) - x, y - Math.floor(y), Math.ceil(y) - y);
      const line = clamp(edge / 0.025, 0, 1);
      color = color.map(v => v * (0.52 + 0.48 * line)); roughness = 0.8;
      // Distinct x/y reference lines remain part of the floor geometry.
      if (Math.abs(x) < 0.018) color = [0.66, 0.31, 0.27];
      if (Math.abs(y) < 0.018) color = [0.24, 0.57, 0.56];
    }
    let shadow = 1;
    for (let i = 0; i < scene.spheres.length; i++) {
      if (i === hit.index) continue;
      const s = scene.spheres[i], q = [p[0] - s.c[0], p[1] - s.c[1], p[2] - s.c[2]];
      const along = -dot(q, LIGHT);
      if (along > 0) {
        const perpendicular = Math.sqrt(Math.max(0, dot(q, q) - along * along));
        shadow *= 0.4 + 0.6 * clamp((perpendicular / s.r - 0.75) / 0.3, 0, 1);
      }
    }
    const diffuse = Math.max(0, dot(n, LIGHT));
    const half = unit([LIGHT[0] - u[0], LIGHT[1] - u[1], LIGHT[2] - u[2]]);
    const spec = Math.pow(Math.max(0, dot(n, half)), hit.sphere ? 70 : 25) * (1 - roughness) * shadow;
    const rim = Math.pow(1 - clamp(-dot(n, u), 0, 1), 3) * (hit.sphere ? 0.16 : 0);
    const illumination = 0.25 + diffuse * shadow * 0.85;
    const fog = 1 - Math.exp(-Math.max(0, distance - scene.scale * 5) / (scene.scale * 38));
    const bg = sky(u);
    return color.map((v, i) => (v * illumination + spec * 0.9 + rim * [0.3, 0.55, 0.7][i]) * (1 - fog) + bg[i] * fog);
  }

  function pixelRay(origin, direction, field, bounds, strength, scene, baseStep, maxDistance) {
    let p = origin, u = direction, distance = 0;
    const entry = boxEntry(p, u, bounds);
    if (!entry || strength === 0) {
      const hit = hitScene(p, u, maxDistance, scene);
      return hit ? shade(hit, u, scene, hit.t) : sky(u);
    }
    if (entry[0] > 0) {
      const first = hitScene(p, u, entry[0], scene);
      if (first) return shade(first, u, scene, first.t);
      // Step just inside, so a boundary sample cannot accidentally omit entry.
      const advance = entry[0] + 1e-7;
      p = [p[0] + advance * u[0], p[1] + advance * u[1], p[2] + advance * u[2]];
      distance += advance;
    }
    for (let k = 0; k < 240 && distance < maxDistance; k++) {
      if (!inside(p, bounds, 1e-6)) {
        const hit = hitScene(p, u, maxDistance - distance, scene);
        return hit ? shade(hit, u, scene, distance + hit.t) : sky(u);
      }
      const f = sample(field, p, bounds);
      const h = Math.min(baseStep, 0.2 / (Math.abs(strength) * Math.hypot(...f) + 1e-8));
      const next = rk2(p, u, field, strength, h, bounds, f);
      const delta = [next.p[0] - p[0], next.p[1] - p[1], next.p[2] - p[2]];
      const length = Math.hypot(...delta), chord = unit(delta);
      const hit = hitScene(p, chord, length, scene);
      if (hit) return shade(hit, chord, scene, distance + hit.t);
      p = next.p; u = next.u; distance += length;
    }
    return sky(u);
  }

  function render(options) {
    const o = options || {}, width = Number(o.width === undefined ? 240 : o.width), height = Number(o.height === undefined ? 180 : o.height);
    if (!Number.isInteger(width) || !Number.isInteger(height) || width < 1 || height < 1 || width * height > 4000000) throw new RangeError('Invalid render dimensions.');
    const bounds = checkedBounds(o.bounds), field = o.field || (() => [0, 0, 0]);
    const strength = o.strength === undefined ? 0.35 : Number(o.strength);
    if (!Number.isFinite(strength)) throw new RangeError('strength must be finite.');
    const scene = sceneFor(bounds);
    const center = bounds.map(b => (b[0] + b[1]) / 2);
    const yaw = Number(o.yaw || 0), pitch = clamp(Number(o.pitch || 0), -1.1, 1.1);
    const distance = Number(o.cameraDistance === undefined ? 9.49 * scene.scale : o.cameraDistance);
    if (!Number.isFinite(yaw) || !Number.isFinite(pitch) || !(distance > 0) || !Number.isFinite(distance)) throw new RangeError('Invalid camera settings.');
    const angle = Math.atan2(-7, 5) + yaw, elevation = Math.atan2(4, Math.hypot(5, 7)) + pitch;
    const origin = [center[0] + distance * Math.cos(elevation) * Math.cos(angle), center[1] + distance * Math.cos(elevation) * Math.sin(angle), center[2] + distance * Math.sin(elevation)];
    const target = [center[0], center[1], center[2] - 1.15 * scene.scale];
    const forward = unit(target.map((x, i) => x - origin[i]));
    let right = unit(cross(forward, [0, 0, 1]));
    if (Math.hypot(...right) < EPS) right = [1, 0, 0];
    const up = cross(right, forward);
    const view = Math.tan((o.fov || 45) * Math.PI / 360), aspect = width / height;
    const data = new Uint8ClampedArray(width * height * 4);
    for (let y = 0; y < height; y++) {
      if (o.signal && o.signal.aborted) throw abortError();
      const sy = (1 - 2 * (y + 0.5) / height) * view;
      for (let x = 0; x < width; x++) {
        const sx = (2 * (x + 0.5) / width - 1) * view * aspect;
        const u = unit([forward[0] + sx * right[0] + sy * up[0], forward[1] + sx * right[1] + sy * up[1], forward[2] + sx * right[2] + sy * up[2]]);
        let c;
        try {
          c = pixelRay(origin, u, field, bounds, strength, scene, scene.scale * 0.105, scene.scale * 70);
        } catch (e) {
          // Neutral gray marks a path whose numerical field is undefined.
          // It is an unavailable sample, not a physical absorption model.
          if (!e || e.name !== 'FieldSampleError') throw e;
          c = [0.055, 0.055, 0.055];
        }
        const vignette = 1 - 0.12 * ((sx / (view * aspect)) ** 2 + (sy / view) ** 2);
        const index = (y * width + x) * 4;
        for (let ch = 0; ch < 3; ch++) data[index + ch] = Math.round(255 * Math.pow(clamp(c[ch] * vignette, 0, 1), 1 / 2.2));
        data[index + 3] = 255;
      }
    }
    return data;
  }

  const api = {render, traceRay};
  root.RayRenderer = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof globalThis !== 'undefined' ? globalThis : this);
