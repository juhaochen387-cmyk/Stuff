#!/usr/bin/env python3
"""Local-only Wolfram Language sampling bridge. Python 3.9+, no dependencies."""
from __future__ import annotations

import argparse
import functools
import hmac
import json
import math
import os
from pathlib import Path
import secrets
import shutil
import signal
import subprocess
import tempfile
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

ROOT = Path(__file__).resolve().parent
MAX_BODY = 2 * 1024 * 1024


class BridgeError(Exception):
    def __init__(self, message: str, status: int = 400):
        super().__init__(message)
        self.status = status


def validate_request(data):
    if not isinstance(data, dict):
        raise BridgeError("Expected a JSON object.")
    definitions = data.get("definitions", "")
    components = data.get("components")
    bounds = data.get("bounds")
    resolution = data.get("resolution")
    if not isinstance(definitions, str):
        raise BridgeError("Definitions must be Wolfram Language source text.")
    if not isinstance(components, list) or len(components) != 3 or not all(
        isinstance(s, str) and s.strip() for s in components
    ):
        raise BridgeError("Provide three nonempty component expressions.")
    if type(resolution) is not int or not 7 <= resolution <= 31:
        raise BridgeError("Resolution must be an integer between 7 and 31.")
    if not isinstance(bounds, list) or len(bounds) != 3:
        raise BridgeError("Bounds must contain three [minimum, maximum] pairs.")
    checked = []
    for axis in bounds:
        if not isinstance(axis, list) or len(axis) != 2 or not all(
            type(v) in (int, float) and math.isfinite(v) for v in axis
        ):
            raise BridgeError("Axis bounds must be finite real numbers.")
        if axis[0] >= axis[1]:
            raise BridgeError("Every minimum bound must be less than its maximum.")
        checked.append([float(axis[0]), float(axis[1])])
    return dict(definitions=definitions, components=components, bounds=checked,
                resolution=resolution)


def kernel_executable(explicit=None):
    candidate = explicit or os.environ.get("WOLFRAMSCRIPT") or "wolframscript"
    found = shutil.which(candidate)
    return found or (candidate if Path(candidate).is_file() else None)


def run_kernel(request, executable, timeout=90):
    if not executable:
        raise BridgeError(
            "WolframScript was not found. Install and activate Wolfram Engine or "
            "Mathematica, then restart this bridge. No API key is required.", 503)
    with tempfile.TemporaryDirectory(prefix="vector-space-") as folder:
        request_path = Path(folder) / "request.json"
        result_path = Path(folder) / "result.json"
        request_path.write_text(json.dumps(request, ensure_ascii=False), encoding="utf-8")
        command = [executable, "-local", "-file", str(ROOT / "sample.wls"),
                   str(request_path), str(result_path)]
        # User Print output cannot corrupt the JSON protocol or exhaust captured memory.
        with tempfile.TemporaryFile() as output:
            try:
                process = subprocess.Popen(command, stdin=subprocess.DEVNULL,
                    stdout=output, stderr=output, start_new_session=(os.name != "nt"))
                try:
                    process.wait(timeout=timeout)
                except subprocess.TimeoutExpired:
                    if os.name != "nt":
                        os.killpg(process.pid, signal.SIGKILL)
                    else:
                        subprocess.run(["taskkill", "/F", "/T", "/PID", str(process.pid)],
                                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                                       check=False)
                        process.kill()
                    process.wait()
                    raise BridgeError("Wolfram evaluation timed out. Simplify definitions "
                                      "or reduce grid resolution.", 504)
            except OSError as error:
                raise BridgeError("Could not start WolframScript: " + str(error), 503) from error
        if not result_path.is_file():
            raise BridgeError("The local Wolfram kernel returned no result. Check that "
                              "WolframScript is activated by running wolframscript -local "
                              "-code '1+1' in a terminal.", 502)
        try:
            result = json.loads(result_path.read_text(encoding="utf-8"))
        except (ValueError, OSError) as error:
            raise BridgeError("The Wolfram kernel returned invalid JSON.", 502) from error
        if not isinstance(result, dict):
            raise BridgeError("Unexpected Wolfram kernel response.", 502)
        if "error" in result:
            raise BridgeError(str(result["error"]), 422)
        vectors = result.get("vectors")
        n = request["resolution"]
        if not isinstance(vectors, list) or len(vectors) != n ** 3:
            raise BridgeError("Wolfram returned the wrong number of samples.", 502)
        clean = []
        for value in vectors:
            if isinstance(value, list) and len(value) == 3 and all(
                type(v) in (int, float) and math.isfinite(v) for v in value
            ):
                clean.append(value)
            else:
                clean.append(None)
        if all(v is None for v in clean):
            raise BridgeError("No finite real vector samples. Check definitions and "
                              "components; x, y and z are bound to numeric coordinates.", 422)
        return dict(vectors=clean, invalid=sum(v is None for v in clean),
                    resolution=n, bounds=request["bounds"])


class Handler(BaseHTTPRequestHandler):
    server_version = "VectorSpace/1.0"

    def __init__(self, *args, token, executable, timeout, **kwargs):
        self.token = token
        self.executable = executable
        self.timeout = timeout
        super().__init__(*args, **kwargs)

    def log_message(self, *_args):
        pass  # Do not log program text or authentication material.

    def _check_request(self):
        port = self.server.server_address[1]
        if self.headers.get("Host") not in (f"127.0.0.1:{port}", f"localhost:{port}"):
            raise BridgeError("This service accepts localhost requests only.", 403)
        origin = self.headers.get("Origin")
        allowed = (None, "null", f"http://127.0.0.1:{port}", f"http://localhost:{port}")
        if origin not in allowed:
            raise BridgeError("Origin is not allowed.", 403)
        return origin

    def _headers(self, status, content_type="application/json", length=0):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(length))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        port = self.server.server_address[1]
        origin = self.headers.get("Origin")
        if origin in ("null", f"http://127.0.0.1:{port}", f"http://localhost:{port}"):
            self.send_header("Access-Control-Allow-Origin", origin)
            self.send_header("Vary", "Origin")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, X-Vector-Token")
        # Chromium may require a local-network preflight from file:// pages.
        if self.headers.get("Access-Control-Request-Private-Network") == "true":
            self.send_header("Access-Control-Allow-Private-Network", "true")
        self.end_headers()

    def _json(self, status, value):
        body = json.dumps(value, ensure_ascii=False, allow_nan=False).encode("utf-8")
        self._headers(status, length=len(body))
        self.wfile.write(body)

    def do_OPTIONS(self):
        try:
            self._check_request()
            self._headers(204)
        except BridgeError as error:
            self._json(error.status, {"error": str(error)})

    def do_GET(self):
        try:
            self._check_request()
            if self.path == "/health":
                return self._json(200, {"ok": True, "kernelAvailable": bool(self.executable),
                    "kernelStatus": "executable detected; activation verified on evaluation"
                        if self.executable else "WolframScript not found"})
            if self.path not in ("/", "/index.html"):
                return self._json(404, {"error": "Not found."})
            path = ROOT / "index.html"
            if not path.is_file():
                return self._json(404, {"error": "Place index.html beside bridge.py."})
            body = path.read_bytes()
            self._headers(200, "text/html; charset=utf-8", len(body))
            self.wfile.write(body)
        except BridgeError as error:
            self._json(error.status, {"error": str(error)})

    def do_POST(self):
        try:
            self._check_request()
            if self.path != "/sample":
                raise BridgeError("Not found.", 404)
            supplied = self.headers.get("X-Vector-Token", "")
            if not hmac.compare_digest(supplied, self.token):
                raise BridgeError("Connection token is missing or incorrect. Use the token "
                                  "printed when the local bridge starts.", 401)
            if self.headers.get_content_type() != "application/json":
                raise BridgeError("Content-Type must be application/json.", 415)
            try:
                length = int(self.headers.get("Content-Length", "0"))
            except ValueError:
                raise BridgeError("Invalid Content-Length.")
            if not 0 < length <= MAX_BODY:
                raise BridgeError("Request must be nonempty and smaller than 2 MiB.", 413)
            try:
                data = json.loads(self.rfile.read(length).decode("utf-8"),
                                  parse_constant=lambda v: (_ for _ in ()).throw(ValueError(v)))
            except (UnicodeError, ValueError):
                raise BridgeError("Invalid JSON request.")
            request = validate_request(data)
            # One kernel at a time avoids starting multiple licensed kernels accidentally.
            if not self.server.kernel_lock.acquire(blocking=False):
                raise BridgeError("A Wolfram evaluation is already running. Please wait.", 409)
            try:
                result = run_kernel(request, self.executable, self.timeout)
            finally:
                self.server.kernel_lock.release()
            self._json(200, result)
        except BridgeError as error:
            self._json(error.status, {"error": str(error)})


def make_server(port=8765, token=None, executable=None, timeout=90):
    import threading
    factory = functools.partial(Handler, token=token or secrets.token_urlsafe(32),
                                executable=executable, timeout=timeout)
    server = ThreadingHTTPServer(("127.0.0.1", port), factory)
    server.daemon_threads = True
    server.kernel_lock = threading.Lock()
    return server


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--port", type=int, default=8765)
    parser.add_argument("--wolframscript", help="Path to the wolframscript executable")
    parser.add_argument("--timeout", type=float, default=90)
    options = parser.parse_args()
    if not 1 <= options.port <= 65535 or not math.isfinite(options.timeout) or options.timeout <= 0:
        parser.error("Use a valid port and a positive finite timeout.")
    token = secrets.token_urlsafe(32)
    executable = kernel_executable(options.wolframscript)
    try:
        server = make_server(options.port, token, executable, options.timeout)
    except OSError as error:
        parser.exit(1, f"Could not start the local bridge: {error}\n")
    print("Vector Space — local Wolfram bridge", flush=True)
    print(f"Open http://127.0.0.1:{options.port}/#token={token}", flush=True)
    print("Connection token: " + token, flush=True)
    print("WolframScript: " + ("detected; activated kernel required" if executable else "not found"),
          flush=True)
    print("Only run definitions you trust: Wolfram code runs with your user permissions.", flush=True)
    print("Press Ctrl+C to stop.", flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
