import importlib.util
import json
from pathlib import Path
import tempfile
import threading
import unittest
from urllib.error import HTTPError
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("bridge", ROOT / "bridge.py")
bridge = importlib.util.module_from_spec(spec)
spec.loader.exec_module(bridge)


def payload(**changes):
    value = dict(definitions="a = 2; f[t_?NumericQ] := Sin[t];",
                 components=["-y", "x", "a f[z]"],
                 bounds=[[-2, 2], [-2, 2], [-2, 2]], resolution=7)
    value.update(changes)
    return value


class ValidationTests(unittest.TestCase):
    def test_valid_request_keeps_exact_source(self):
        source = '(* λ *)\nf[t_] := Module[{q = t^2}, q + Sin[t]];'
        result = bridge.validate_request(payload(definitions=source))
        self.assertEqual(result["definitions"], source)
        self.assertEqual(result["resolution"], 7)

    def test_rejects_invalid_grid(self):
        for change in ({"resolution": True}, {"resolution": 32},
                       {"bounds": [[0, 0], [-2, 2], [-2, 2]]},
                       {"bounds": [[float("nan"), 2], [-2, 2], [-2, 2]]},
                       {"components": ["x", "y"]}):
            with self.subTest(change=change), self.assertRaises(bridge.BridgeError):
                bridge.validate_request(payload(**change))

    def test_missing_kernel_explains_requirement(self):
        with self.assertRaises(bridge.BridgeError) as error:
            bridge.run_kernel(payload(), None)
        self.assertEqual(error.exception.status, 503)
        self.assertIn("No API key", str(error.exception))

    def test_subprocess_json_transport_and_nonreal_filter(self):
        # A fixture executable tests the subprocess/file protocol without impersonating
        # or claiming to test a licensed Wolfram runtime.
        with tempfile.TemporaryDirectory() as folder:
            executable = Path(folder) / "fixture-kernel"
            executable.write_text(
                '#!/usr/bin/env python3\n'
                'import json, pathlib, sys\n'
                'request = json.loads(pathlib.Path(sys.argv[-2]).read_text())\n'
                'assert sys.argv[1:3] == ["-local", "-file"]\n'
                'assert "Module" in request["definitions"]\n'
                'v = [[1, 2, 3]] * (request["resolution"] ** 3)\n'
                'v[0] = ["complex", 0, 0]\n'
                'pathlib.Path(sys.argv[-1]).write_text(json.dumps({"vectors": v}))\n',
                encoding="utf-8")
            executable.chmod(0o755)
            value = payload(definitions='f[t_] := Module[{q = t^2}, q];')
            result = bridge.run_kernel(value, str(executable), timeout=5)
            self.assertEqual(len(result["vectors"]), 343)
            self.assertIsNone(result["vectors"][0])
            self.assertEqual(result["vectors"][-1], [1, 2, 3])
            self.assertEqual(result["invalid"], 1)

    def test_timeout_terminates_subprocess(self):
        with tempfile.TemporaryDirectory() as folder:
            executable = Path(folder) / "slow-fixture"
            executable.write_text('#!/usr/bin/env python3\nimport time\ntime.sleep(30)\n')
            executable.chmod(0o755)
            with self.assertRaises(bridge.BridgeError) as error:
                bridge.run_kernel(payload(), str(executable), timeout=0.1)
            self.assertEqual(error.exception.status, 504)


@unittest.skipUnless(bridge.kernel_executable(), "Activated WolframScript is not available")
class RealKernelTests(unittest.TestCase):
    def test_needs_exports_remain_available_to_component_expressions(self):
        # This exercises actual Wolfram context resolution, not a mocked output
        # or a textual assertion about the implementation.
        with tempfile.TemporaryDirectory() as folder:
            package = Path(folder) / "VectorBridgeFixture.wl"
            package.write_text(
                'BeginPackage["VectorBridgeFixture`"];\n'
                'BridgeFixtureScale::usage = "Test exported numeric function.";\n'
                'x::usage = "A package export must not capture the coordinate x.";\n'
                'Begin["`Private`"];\n'
                'BridgeFixtureScale[t_] := 2 t;\n'
                'x = 999;\n'
                'End[];\nEndPackage[];\n', encoding="utf-8")
            definitions = 'Needs["VectorBridgeFixture`", ' + json.dumps(str(package)) + '];'
            request = bridge.validate_request(payload(definitions=definitions,
                components=["BridgeFixtureScale[x]", "y", "z"]))
            result = bridge.run_kernel(request, bridge.kernel_executable())
            self.assertEqual(result["invalid"], 0)
            self.assertEqual(result["vectors"][0], [-4, -2, -2])
            self.assertEqual(result["vectors"][-1], [4, 2, 2])


class HttpTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = bridge.make_server(0, "test-token", None)
        cls.port = cls.server.server_address[1]
        cls.url = f"http://127.0.0.1:{cls.port}"
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()
        cls.thread.join()

    def call(self, path, method="GET", body=None, headers=None):
        request = Request(self.url + path,
            data=json.dumps(body).encode() if body is not None else None,
            method=method, headers=headers or {})
        try:
            return urlopen(request, timeout=5)
        except HTTPError as error:
            return error

    def test_health_does_not_claim_activation(self):
        with self.call("/health", headers={"Origin": "null"}) as response:
            self.assertEqual(response.status, 200)
            self.assertEqual(response.headers["Access-Control-Allow-Origin"], "null")
            self.assertFalse(json.load(response)["kernelAvailable"])

    def test_unknown_origin_rejected(self):
        with self.call("/health", headers={"Origin": "https://evil.example"}) as response:
            self.assertEqual(response.status, 403)
            self.assertIsNone(response.headers.get("Access-Control-Allow-Origin"))

    def test_rebinding_host_rejected(self):
        with self.call("/health", headers={"Host": "attacker.example"}) as response:
            self.assertEqual(response.status, 403)

    def test_file_origin_preflight(self):
        with self.call("/sample", "OPTIONS", headers={"Origin": "null",
                "Access-Control-Request-Private-Network": "true"}) as response:
            self.assertEqual(response.status, 204)
            self.assertEqual(response.headers["Access-Control-Allow-Private-Network"], "true")
            self.assertIn("X-Vector-Token", response.headers["Access-Control-Allow-Headers"])

    def test_missing_token_rejected(self):
        with self.call("/sample", "POST", payload(), {"Content-Type": "application/json"}) as response:
            self.assertEqual(response.status, 401)

    def test_authorized_missing_kernel_is_explicit(self):
        with self.call("/sample", "POST", payload(), {
            "Content-Type": "application/json", "X-Vector-Token": "test-token"
        }) as response:
            self.assertEqual(response.status, 503)
            self.assertIn("WolframScript", json.load(response)["error"])

    def test_invalid_payload_rejected_before_evaluation(self):
        with self.call("/sample", "POST", payload(resolution=1000), {
            "Content-Type": "application/json", "X-Vector-Token": "test-token"
        }) as response:
            self.assertEqual(response.status, 400)

    def test_directory_traversal_is_not_served(self):
        with self.call("/../bridge.py") as response:
            self.assertEqual(response.status, 404)


if __name__ == "__main__":
    unittest.main()
