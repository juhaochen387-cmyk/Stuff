const assert = require('node:assert/strict');
const {render, traceRay} = require('../rays.js');

const straight = traceRay({origin: [1, -2, 3], direction: [2, 0, 0], field: () => [0, 0, 0], step: 0.02, steps: 250});
assert.ok(Math.abs(straight.position[0] - 6) < 1e-11);
assert.deepEqual(straight.position.slice(1), [-2, 3]);
assert.deepEqual(straight.direction, [1, 0, 0]);

// For F=(0,1,0), u=(sech(s),tanh(s),0), p=(atan(sinh(s)),log(cosh(s)),0).
const curved = traceRay({origin: [0, 0, 0], direction: [1, 0, 0], field: () => [0, 1, 0], strength: 1, step: 0.005, steps: 200});
assert.ok(Math.abs(curved.position[0] - Math.atan(Math.sinh(1))) < 2e-5);
assert.ok(Math.abs(curved.position[1] - Math.log(Math.cosh(1))) < 2e-5);
assert.ok(Math.abs(curved.direction[0] - 1 / Math.cosh(1)) < 2e-5);
assert.ok(Math.abs(curved.direction[1] - Math.tanh(1)) < 2e-5);
assert.ok(Math.abs(Math.hypot(...curved.direction) - 1) < 1e-12);

// A field parallel to the tangent must not bend a ray.
const parallel = traceRay({field: () => [99, 0, 0], strength: 2, steps: 50});
assert.deepEqual(parallel.direction, [1, 0, 0]);
assert.ok(Math.abs(parallel.position[0] - 1) < 1e-12);

const domain = traceRay({origin: [2, 0, 0], direction: [1, 0, 0], field: () => [0, 1, 0], bounds: [[-1, 1], [-1, 1], [-1, 1]], strength: 1, steps: 20});
assert.deepEqual(domain.direction, [1, 0, 0]);

// Undefined in-domain regions must never be substituted with a zero field.
assert.throws(() => traceRay({field: (x) => x >= 0.3 ? [NaN, 0, 0] : [1, 0, 0], steps: 50}), {
  name: 'FieldSampleError', message: /Field is undefined or non-real at/
});
const outsideSingularity = traceRay({origin: [2, 0, 0], field: () => null, bounds: [[-1, 1], [-1, 1], [-1, 1]], steps: 20});
assert.deepEqual(outsideSingularity.direction, [1, 0, 0]);

const baseline = render({width: 40, height: 30, strength: 0, field: () => [0, 0, 0]});
const zero = render({width: 40, height: 30, strength: 0.6, field: () => [0, 0, 0]});
assert.equal(baseline.length, 40 * 30 * 4);
assert.ok(zero.every(Number.isFinite));
for (let i = 3; i < zero.length; i += 4) assert.equal(zero[i], 255);
// Curved-path stepping with a zero field reproduces the straight scene up to rounding.
let delta = 0;
for (let i = 0; i < zero.length; i++) delta = Math.max(delta, Math.abs(zero[i] - baseline[i]));
assert.ok(delta <= 1, 'zero-field render must equal straight Euclidean rays');

const bent = render({width: 40, height: 30, strength: 0.3, field: () => [0.2, -0.1, 0.1]});
assert.ok(bent.some((value, i) => value !== baseline[i]), 'nonparallel fields should alter the image');
const undefinedRegion = render({width: 40, height: 30, strength: 0.3, field: () => [NaN, 0, 0]});
let unavailablePixels = 0;
for (let i = 0; i < undefinedRegion.length; i += 4) {
  if (undefinedRegion[i] === undefinedRegion[i + 1] && undefinedRegion[i] === undefinedRegion[i + 2] && undefinedRegion[i] < 80) unavailablePixels++;
}
assert.ok(unavailablePixels > 0, 'undefined regions must have a distinguishable neutral marker');
assert.throws(() => render({width: 10, height: 10, signal: {aborted: true}}), {name: 'AbortError'});
assert.throws(() => traceRay({direction: [0, 0, 0]}), RangeError);
console.log('Ray renderer: straight rays, analytic bend, unit speed, domain, singular regions, render, cancellation passed.');
