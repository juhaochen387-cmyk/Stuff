'use strict';
const assert = require('node:assert/strict');
const F = require('../field.js');
const bounds = [[-2, 2], [-2, 2], [-2, 2]];
const close = (a, b, e = 1e-7) => assert.ok(Math.abs(a - b) < e, `${a} ≈ ${b}`);

const circle = (x, y, z) => [-y, x, 0];
let d = F.diagnostics(circle, [1.5, 0, 0], bounds);
close(d.kappa, 1 / 1.5);
close(d.divergence, 0);
assert.deepEqual(d.curl, [0, 0, 2]);
assert.equal(F.diagnostics(circle, [0, 0, 0], bounds).kappa, null);

const constant = () => [1, 2, 3];
d = F.diagnostics(constant, [0.1, 0.2, 0.3], bounds);
close(d.kappa, 0); close(d.divergence, 0);
assert.deepEqual(d.curl, [0, 0, 0]);
close(F.diagnostics((x, y, z) => [x, y, z], [2, 2, 2], bounds).divergence, 3);

const n = 3, vectors = [];
for (let x = -2; x <= 2; x += 2) for (let y = -2; y <= 2; y += 2) for (let z = -2; z <= 2; z += 2) vectors.push([2*x + y, y - z, x + z]);
let sample = F.interpolateGrid(vectors, n, bounds);
assert.deepEqual(sample(.5, -.5, .25), [.5, -.75, .75]);
assert.equal(sample(2.001, 0, 0), null);
assert.deepEqual(sample(2, 2, 2), [6, 0, 4]);
vectors[1] = null;
sample = F.interpolateGrid(vectors, n, bounds);
assert.deepEqual(sample(-2, -2, -2), [-6, 0, -4]);
assert.equal(sample(-2, -2, -1), null);
assert.throws(() => F.interpolateGrid([], 3, bounds), /size/);

const radial = (x, y, z) => [x - .123, y + .234, z - .345];
const data = F.build(radial, bounds, { density: 5, seedCount: 12, steps: 50 });
assert.equal(data.invalid, 0);
assert.equal(data.nulls.length, 1);
data.nulls[0].p.forEach((p, i) => close(p, [.123, -.234, .345][i]));
assert.ok(data.nulls[0].residual < 1e-7);
assert.ok(data.lines.length > 0);
assert.ok(data.lines.every(line => line.points.every(p => p.every((v, i) => v >= bounds[i][0] && v <= bounds[i][1]))));
assert.equal(data.nullEverywhere, false);
const zero = F.build(() => [0, 0, 0], bounds, { seedCount: 4 });
assert.equal(zero.nullEverywhere, true);
assert.equal(zero.lines.length, 0);
assert.equal(zero.nulls.length, 0);
const broken = F.build(() => [Infinity, 0, 0], bounds, { density: 3, seedCount: 2 });
assert.equal(broken.invalid, 27);
assert.equal(broken.nullEverywhere, false);
assert.deepEqual(F.diagnostics(() => [NaN, 1, 2], [0,0,0], bounds), {v:null, speed:null, kappa:null, divergence:null, curl:null});

// Normalized RK4 retains a circular field's radius over the traced line.
const circles = F.build(circle, bounds, { density: 3, seedCount: 5, steps: 180 });
for (const line of circles.lines) {
  const radius = Math.hypot(...line.points[0].slice(0, 2));
  for (const point of line.points) close(Math.hypot(...point.slice(0, 2)), radius, 1e-3);
}
console.log('FieldMath tests passed');
