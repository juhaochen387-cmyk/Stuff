# Vector Space

An HTML laboratory for a real three-dimensional vector field
`F(x,y,z) = {X(x,y,z), Y(x,y,z), Z(x,y,z)}`. Open **index.html** directly in
a current desktop browser. Its interface, renderer and common-expression preview
are self-contained; no build, web hosting or API key is needed.

## Full Wolfram Language evaluation

Full Mathematica syntax and definitions require a real Wolfram kernel. This
package includes a Python standard-library bridge to your locally installed,
activated **Wolfram Engine or Mathematica**. It does not translate your source
into JavaScript and does not use the Wolfram|Alpha API.

1. Install Python 3.9 or later and an activated Wolfram installation with
   `wolframscript` available on your PATH.
2. In a terminal, verify `wolframscript -local -code "1+1"` returns `2`.
3. Extract the whole ZIP. Run `python3 bridge.py` (macOS/Linux) or
   `py -3 bridge.py` (Windows) inside its folder. Convenience launchers are
   included; on macOS/Linux you may first need to run
   `chmod +x start-wolfram.command`.
4. Open the localhost URL printed by the bridge. Its URL fragment contains the
   connection token, which the app reads. Select the Wolfram engine in the app.
   Alternatively, open index.html from disk and paste that token in the engine
   settings. If your browser blocks file-to-localhost requests, use the printed
   localhost URL.

No API key is required. Wolfram activation/licensing is separate from an API key.
Functions needing extra Wolfram packages, network services, credentials or a
notebook front end still need those dependencies. A kernel cannot display
arbitrary nonnumerical expressions as vectors: each displayed component must
evaluate to a finite real number at the sampled coordinates.

If WolframScript is not on PATH, use:

```sh
python3 bridge.py --wolframscript "/path/to/wolframscript"
```

`--port 8765` and `--timeout 90` can be adjusted. Every evaluation starts a fresh
local kernel, evaluates the definitions once, then samples a regular grid. This
prevents earlier definitions from silently affecting the next evaluation. Source
is transported unchanged in a JSON file. User `Print` output is kept separate
from the result protocol. A new connection token is generated at each launch.

## Writing equations

The three component editors contain Wolfram **expressions**, with lowercase
`x`, `y`, `z` bound to numeric coordinates. Use normal square brackets and exact
Wolfram capitalization:

```wl
(* Definitions editor *)
a = 0.35;
f[t_?NumericQ] := Module[{q = t^2}, Exp[-q]];
X[x_, y_, z_] := -y f[x];
Y[x_, y_, z_] := x f[y];
Z[x_, y_, z_] := a Sin[z];
```

Then put `X[x,y,z]`, `Y[x,y,z]`, `Z[x,y,z]` in the corresponding component
editors. Or enter `-y`, `x`, `0.35 Sin[z]` directly. Definitions such as
`SetDelayed`, patterns, `Module`, `Piecewise`, symbolic functions, imports and
package loading are evaluated by the Wolfram kernel according to its installed
version and dependencies. Local preview deliberately supports a smaller subset;
switch to the kernel for other language features. No browser-only parser is
claimed to implement all of Mathematica.

Package contexts added by `Needs` or `Get` in the definitions remain available to
component expressions. The component coordinate names always refer to
``Global`x``, ``Global`y``, ``Global`z``; qualify other symbols explicitly when needed.

Only run definitions you trust. They are executable local Wolfram programs with
the permissions of your user account, including file and network access. The
bridge binds to 127.0.0.1, requires a random token for evaluations, checks Host
and Origin, and permits the app's file origin. It is a personal local tool, not
an Internet-facing multiuser execution service.

## What “curvature” means here

An arbitrary vector field alone does not determine a Riemannian metric or its
intrinsic curvature. With the standard Euclidean metric, intrinsic curvature is
zero, and a vector of zero norm must itself be zero. In relativity, a nonzero
lightlike four-vector can instead be null in a Lorentzian metric. Three spatial
component functions alone do not specify that metric or a complete null
four-vector field. The app's “null set” means points where `F = 0`; this should
not be confused with Lorentzian lightlike vectors. The rendering uses the
explicitly defined bending model below.

Streamlines solve `dr/dt = F(r)`. Their geometric curvature is
`kappa = |F cross (J_F F)| / |F|^3`; it is undefined at a null. Numerical grid
interpolation and finite differences provide approximate visualizations.

The curved-ray view uses the explicit unit-speed bending equation
`dr/ds = u`, `du/ds = strength * (F - (F.u) u)`. The zero field gives straight
rays. If `strength*F = grad(phi)`, these unparameterized curves agree with
geodesics of the conformal metric `g = exp(2 phi) I`. For arbitrary fields this
is a defined ray-bending model, and it is not claimed to recover a unique
physical geometry. See the app's model information for its controls.

This ray integration is inspired by the geodesic rendering explanation at
[3-dimensional.space/render](https://3-dimensional.space/render/). That project
starts with a defined geometry; this app makes its extra field-to-ray assumption
explicit.

The supplied [Ray Tracing Curved Spacetime report](https://cameroneure.com/wp-content/uploads/2023/01/relativity_project-1.pdf)
uses a four-dimensional Lorentzian metric, derives Christoffel symbols and
integrates null geodesics. In that setting a null four-velocity is nonzero but
has zero metric norm; it is not the zero spatial vector field. Its Appendix A
shows metric-driven equations. The requested three component functions do not
uniquely determine that metric. This app therefore does not claim to implement
the report's Schwarzschild/Kerr model. It integrates the explicit bending model
above and explains this choice in the interface.

## Numerical and runtime limits

- Sampling is finite. Small features, discontinuities, thin zero sets and
  singularities may be missed. Invalid, complex or nonfinite samples are omitted.
- Kernel grids contain between 7 and 31 points per axis. Displayed curves and
  rays interpolate that grid rather than invoke the kernel at each integration
  step. Increasing resolution improves some features but does not prove
  convergence or certify null detection.
- Changes to definitions/components need a new render/evaluation; changing a
  camera or visual style reuses the current data.
- The full Wolfram path needs the included bridge and an activated installation.
  The single HTML file still opens and runs its preview without them.

## Included examples and source

Use Open project to load `examples/helical-flow.json`, or select Wolfram kernel
and load `examples/full-wolfram-module.json` for a program using `Module`,
`NumericQ` patterns, `Piecewise` and list extraction. Imported projects only run
when you press Apply field.

`index.html` contains all browser code and styles. The editable sources are also
included; run `python3 build.py` to assemble the HTML again after source changes.
There are no CDN or network dependencies for the browser preview. Ray rendering
uses a Blob Web Worker; if your browser restricts local-file workers or local
network requests, use the bridge's localhost URL.

## Developer validation

Run `python3 -m unittest discover -s tests -v` for validation, HTTP/authentication,
origin checks, file transport, result filtering and timeout tests. The protocol
test uses an explicitly fake fixture executable; it does not substitute for an
end-to-end test against a licensed Wolfram kernel. A package-loading regression
test runs when WolframScript is installed and otherwise reports a skip. No
activated Wolfram kernel was available in the build environment, so real-kernel
execution remains an installation-dependent verification step.

Numerical JavaScript checks run with:

```sh
node tests/test_preview.cjs
node tests/test_field.cjs
node tests/test_rays.cjs
```

Browser checks passed through localhost in Chromium for presets, editing,
error recovery, point diagnostics, ray workers, orbit/reset, save/import,
secret exclusion and mobile layout. Direct file navigation was blocked by the
build environment's administrator browser policy, so the double-click route
could not be exercised here. The HTML has no external asset references.
