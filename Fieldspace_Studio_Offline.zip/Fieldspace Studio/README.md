# Fieldspace Studio — offline geodesic field renderer

Open `index.html` directly in a modern browser with **WebGL 2** enabled (Chrome, Firefox, Edge, Safari). No server, CDN, installation or API key is needed. All assets and code are embedded in the HTML.

## Features

- Three editable scalar field components `X[x,y,z]`, `Y[x,y,z]`, `Z[x,y,z]`.
- Wolfram-style expression subset, scalar definitions (`a=2;`) and user-defined functions (`f[x_,y_,z_]:=Sin[x] Exp[-y^2]`). Also honors explicit `X[x_,y_,z_] := ...` in definitions.
- WebGL 2 per-pixel Hamiltonian geodesic tracing for `g = I + α V Vᵀ` with approximate finite-difference gradient, SDF scene intersection, and checker/sphere shading.
- Four geometric scenes, vector arrow overlay, camera orbit/pan/zoom + movement, image download, JSON projects, metric and field diagnostics.

## Important scope

In Euclidean positive-definite three-space, **no nonzero vector is null**. This app interprets the user's arbitrary field as a deformation generating the positive-definite metric `g = I + α V Vᵀ` for `α ≥ 0`. The original Euclidean metric is recovered when `V = 0` or `α = 0`. This is a deliberate modeling choice, not a canonical assignment of metric to vector field, nor a Lorentzian metric.

The offline Wolfram-style parser is a subset, **not a full Mathematica kernel**. Supports `Sin`, `Cos`, `Tan`, `Sinh`, `Cosh`, `Tanh`, `ArcSin`, `ArcCos`, `ArcTan`, `Exp`, `Log`, `Sqrt`, `Abs`, `Sign`, `Floor`, `Ceiling`, `Round`, `Min`, `Max`, `Mod`, `Power`, `UnitStep`, `HeavisideTheta`, `If`, `Piecewise`, `Boole`, `Clip`, constants `Pi`, `E`, `Degree`, `GoldenRatio`, power `^`, arithmetic, implicit multiplication, comparisons, logical conjunction/disjunction, simple scalar and fixed-arity function definitions. Symbolic integration, arbitrary patterns, and Mathematica's full definition system require an actual Wolfram Engine/Cloud and cannot run entirely offline in this app.

Numerical visualization approximates geodesics and is not a certified scientific solver. High-frequency/discontinuous fields and singular functions may produce inaccurate images. Reducing quality/steps improves responsiveness on slower GPUs.

Reference: https://3-dimensional.space/render/ (geodesic rendering and SDF ray marching concept). This is an independently written visualizer, not a copy of that site's implementation.